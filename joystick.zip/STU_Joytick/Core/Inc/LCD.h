/*
 * LCD.h
 *
 *  Created on: May 1, 2026
 *      Author: nitro
 */

#ifndef INC_LCD_H_
#define INC_LCD_H_



#endif /* INC_LCD_H_ */
#ifndef LCD_H
#define LCD_H

#include "main.h"
#include <string.h>
#include <stdio.h>

#define LCD_ADDR    (0x27 << 1)

typedef enum { MODE_MANUAL, MODE_AUTO } RobotMode;
typedef enum { EMG_OFF, EMG_ON }       EmgStatus;

// ตัวแปร global — define ใน main.c, extern ที่นี่
extern RobotMode robot_mode;
extern EmgStatus emg_status;
extern float     current_angle;
extern float     set_angle;
extern uint8_t   angle_sent;

void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_Print(char *str);
void LCD_UpdateAll(void);

#endif
