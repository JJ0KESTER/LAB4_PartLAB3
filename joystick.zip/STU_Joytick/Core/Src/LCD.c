/*
 * LCD.c
 *
 *  Created on: May 1, 2026
 *      Author: nitro
 */
#include "lcd.h"

extern I2C_HandleTypeDef hi2c1;

static void LCD_SendNibble(uint8_t data, uint8_t rs) {
    uint8_t buf = (data & 0xF0) | 0x08 | (rs ? 0x01 : 0x00);
    buf |= 0x04;  HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
    buf &= ~0x04; HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
}

static void LCD_SendCmd(uint8_t cmd) {
    LCD_SendNibble(cmd & 0xF0, 0);
    LCD_SendNibble(cmd << 4,   0);
    HAL_Delay(2);
}

static void LCD_SendData(uint8_t data) {
    LCD_SendNibble(data & 0xF0, 1);
    LCD_SendNibble(data << 4,   1);
    HAL_Delay(2);
}

void LCD_Init(void) {
    HAL_Delay(50);
    LCD_SendNibble(0x30, 0); HAL_Delay(5);
    LCD_SendNibble(0x30, 0); HAL_Delay(1);
    LCD_SendNibble(0x30, 0); HAL_Delay(1);
    LCD_SendNibble(0x20, 0); HAL_Delay(1);
    LCD_SendCmd(0x28); // 4-bit, 2 line
    LCD_SendCmd(0x0C); // display on
    LCD_SendCmd(0x06); // entry mode
    LCD_SendCmd(0x01); // clear
    HAL_Delay(2);
}

void LCD_Clear(void) {
    LCD_SendCmd(0x01);
    HAL_Delay(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
    uint8_t addr[] = {0x00, 0x40, 0x14, 0x54};
    LCD_SendCmd(0x80 | (addr[row] + col));
}

void LCD_Print(char *str) {
    while (*str) LCD_SendData(*str++);
}

void LCD_UpdateAll(void) {
    char buf[21];
    int cur_int = (int)current_angle;
    int cur_dec = (int)((current_angle - cur_int) * 10);
    int set_int = (int)set_angle;
    int set_dec = (int)((set_angle - set_int) * 10);

    LCD_SetCursor(0, 0);
    sprintf(buf, "MODE:%-6s EMG:%-3s",
        robot_mode == MODE_AUTO ? "AUTO" : "MANUAL",
        emg_status == EMG_ON   ? "ON " : "OFF");
    LCD_Print(buf);

    LCD_SetCursor(1, 0);
    sprintf(buf, "Cur:%4d.%1d deg  ", cur_int, cur_dec);
    LCD_Print(buf);

    LCD_SetCursor(2, 0);
    sprintf(buf, "Set:%4d.%1d deg  ", set_int, set_dec);
    LCD_Print(buf);

    LCD_SetCursor(3, 0);
    if (angle_sent) {
        LCD_Print("Status:       SENT!");
    } else {
        LCD_Print("Status:           ");
    }
}

