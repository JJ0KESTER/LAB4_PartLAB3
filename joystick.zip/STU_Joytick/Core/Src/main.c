/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2026 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>
#include "Button_Matrix.h"
#include "LCD.h"
#include "Rotary_encoder.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MCP23017_ADDR   (0x20 << 1)
#define LCD_ADDR    (0x27 << 1)
#define MCP_IODIRA      0x00
#define MCP_IODIRB      0x01
#define MCP_GPPUB       0x0D
#define MCP_GPIOB       0x13
#define MCP_OLATA       0x14
#define MCP_OLATB       0x15

RobotMode robot_mode   = MODE_MANUAL;
EmgStatus emg_status   = EMG_OFF;
float     current_angle = 0.0f;
float     set_angle     = 0.0f;
uint8_t   angle_sent    = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
DMA_HandleTypeDef hdma_i2c1_rx;
DMA_HandleTypeDef hdma_i2c1_tx;

/* USER CODE BEGIN PV */

//UART_HandleTypeDef huart2;  // optional สำหรับ debug
// Matrix 3x3
const char keymap[3][3] = { { '1', '2', '3' }, { '4', '5', '6' }, { '7', '8',
		'9' } };

char current_key = 0;

int test = 0;

// LCD
typedef enum {
	MODE_MANUAL, MODE_AUTO
} RobotMode;
typedef enum {
	EMG_OFF, EMG_ON
} EmgStatus;

RobotMode robot_mode = MODE_MANUAL;
EmgStatus emg_status = EMG_OFF;
float current_angle = 0.0f;
float set_angle = 0.0f;
uint8_t angle_sent = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
HAL_StatusTypeDef MCP_WriteReg(uint8_t reg, uint8_t data) {
//	uint8_t buf[2] = { reg, data };
//	return HAL_I2C_Master_Transmit(&hi2c1, MCP23017_ADDR, buf, 2, HAL_MAX_DELAY);

	return HAL_I2C_Mem_Write(&hi2c1, MCP23017_ADDR, reg, I2C_MEMADD_SIZE_8BIT,
			&data, 1, 100);
}

HAL_StatusTypeDef MCP_ReadReg(uint8_t reg, uint8_t *data) {
//	HAL_StatusTypeDef ret;
//	ret = HAL_I2C_Master_Transmit(&hi2c1, MCP23017_ADDR, &reg, 1,
//	HAL_MAX_DELAY);
//	if (ret != HAL_OK)
//		return ret;
//	return HAL_I2C_Master_Receive(&hi2c1, MCP23017_ADDR, data, 1, HAL_MAX_DELAY);
	return HAL_I2C_Mem_Read(&hi2c1, MCP23017_ADDR, reg, I2C_MEMADD_SIZE_8BIT,
			data, 1, 100);
}

HAL_StatusTypeDef MCP_Init(void);
char ButtonMatrix_Scan();
int _write();

// LCD
void LCD_SendCmd(uint8_t cmd);
void LCD_SendData(uint8_t data);
void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_Print(char *str);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
//	printf("Scanning I2C (detailed)...\r\n");
//	for (uint8_t addr = 0x01; addr < 0x7F; addr++) {
//	    HAL_StatusTypeDef ret = HAL_I2C_IsDeviceReady(&hi2c1, addr << 1, 3, 50);
//	    printf("0x%02X: %d\r\n", addr, ret);  // print ทุก address
//	}
//	printf("Scan done\r\n");
	MCP_Init();
//
//	printf("PB8 mode=%lu af=%lu\r\n", (GPIOB->MODER >> 16) & 0x3, (GPIOB->AFR[1] >> 0) & 0xF);
//	printf("PB9 mode=%lu af=%lu\r\n", (GPIOB->MODER >> 18) & 0x3, (GPIOB->AFR[1] >> 4) & 0xF);
//	uint8_t val;
//	MCP_ReadReg(MCP_IODIRB, &val);
//	printf("IODIRB = 0x%02X (expect 0x38)\r\n", val);
//
//	MCP_ReadReg(MCP_GPPUB, &val);
//	printf("GPPUB  = 0x%02X (expect 0x38)\r\n", val);
//
//	MCP_ReadReg(MCP_OLATB, &val);
//	printf("OLATB  = 0x%02X (expect 0xFF)\r\n", val);
//
//	uint32_t pb8_mode = (GPIOB->MODER >> (8*2)) & 0x3;   // ต้องได้ 0x2 (Alternate)
//	uint32_t pb8_af   = (GPIOB->AFR[1] >> (0*4)) & 0xF;  // ต้องได้ 0x4 (AF4)
//	uint32_t pb9_mode = (GPIOB->MODER >> (9*2)) & 0x3;   // ต้องได้ 0x2
//	uint32_t pb9_af   = (GPIOB->AFR[1] >> (1*4)) & 0xF;  // ต้องได้ 0x4
//
//	printf("PB8 mode=%lu af=%lu\r\n", pb8_mode, pb8_af);
//	printf("PB9 mode=%lu af=%lu\r\n", pb9_mode, pb9_af);

//	HAL_StatusTypeDef status;
//
//	status = HAL_I2C_IsDeviceReady(&hi2c1, 0x20 << 1, 3, 100);
//	printf("IsDeviceReady 0x20: %d\r\n", status);
//
//	// I2C error register
//	printf("I2C ISR: 0x%08lX\r\n", hi2c1.Instance->ISR);
//	printf("I2C ICR: 0x%08lX\r\n", hi2c1.Instance->ICR);
//
	// De-init I2C ก่อน แล้ว toggle PB8 เป็น GPIO ธรรมดา

//	while(1) {
//	    uint8_t dummy = 0x00;
//	    HAL_I2C_Master_Transmit(&hi2c1, 0x20 << 1, &dummy, 1, 100);
//	    HAL_Delay(500);
//	}

//	for (uint8_t a = 0x20; a <= 0x27; a++) {
//	    HAL_StatusTypeDef ret = HAL_I2C_IsDeviceReady(&hi2c1, a << 1, 3, 50);
//	    printf("0x%02X: %s\r\n", a, ret == HAL_OK ? "ACK" : "NACK");
//	}

	char key = 0;
	char last_key = 0;

//	MCP_Init();
//	LCD_Init();
//	LCD_Clear();
//	LCD_SetCursor(0, 0);
//	LCD_Print("Ready...");

	LCD_Init();
	LCD_Clear();
	LCD_UpdateAll();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//		ButtonMatrix_Scan();
		key = ButtonMatrix_Scan();
		test = 555;

		if (key != 0) {
			if (key != last_key) {
				last_key = key;
				current_key = key;
				test = 5555;  // กดครั้งแรก
				printf("Key: %c\r\n", key);
			}
			// ถ้า key == last_key แปลว่ากดค้าง ไม่ต้องทำอะไร
		} else {
			// ปล่อยปุ่มแล้ว
			last_key = 0;
			current_key = 0;
			test = 6666;
		}

//		LCD_UpdateAll();
		HAL_Delay(50);

		// LCD
		if (key != 0 && key != last_key) {
			last_key = key;
			current_key = key;

			char buf[20];
			LCD_SetCursor(0, 0);
			LCD_Print("Button Pressed:     ");
			LCD_SetCursor(1, 0);
			sprintf(buf, "Key: %c            ", key);
			LCD_Print(buf);
		}

		if (key == 0) {
			last_key = 0;
			current_key = 0;
			LCD_SetCursor(0, 0);
			LCD_Print("Waiting...          ");
		}

		LCD_UpdateAll();
		HAL_Delay(200);
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x30A0A7FB;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LPUART1_TX_Pin LPUART1_RX_Pin */
  GPIO_InitStruct.Pin = LPUART1_TX_Pin|LPUART1_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF12_LPUART1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
char ButtonMatrix_Scan(void) {
	uint8_t port_data;
	test = 777;

	for (uint8_t row = 0; row < 3; row++) {
		uint8_t row_mask = ~(1 << row) & 0x07;
		uint8_t out_val = row_mask;
		MCP_WriteReg(MCP_OLATB, out_val); // low
		HAL_Delay(1);

		test = 11;

		MCP_ReadReg(MCP_GPIOB, &port_data);
		uint8_t col_data = (port_data >> 3) & 0x07;

		printf("row=%d out=0x%02X port=0x%02X col=0x%02X\r\n", row, out_val,
				port_data, col_data);

		if (col_data != 0x07) {
			for (uint8_t col = 0; col < 3; col++) {
				if (!(col_data & (1 << col))) {
					test = 10;
					MCP_WriteReg(MCP_OLATB, 0x07);
					return keymap[row][col];
				}
			}
		}
	}

	MCP_WriteReg(MCP_OLATB, 0x07);
	return 0;
}

int _write(int file, char *ptr, int len) {
	for (int i = 0; i < len; i++) {
		ITM_SendChar(*ptr++);
	}
	return len;
}

HAL_StatusTypeDef MCP_Init(void) {
	HAL_StatusTypeDef ret;

	// Reset IOCON ให้แน่ใจว่า BANK=0, SEQOP=0
	    ret = MCP_WriteReg(0x0A, 0x00);
	    if (ret != HAL_OK) return ret;

	    ret = MCP_WriteReg(MCP_IODIRB, 0b00111000);  // bit3-5 = input, bit0-2 = output
	    if (ret != HAL_OK) return ret;

	    ret = MCP_WriteReg(MCP_GPPUB, 0b00111000);   // enable pull-up bit3-5
	    if (ret != HAL_OK) return ret;

	    ret = MCP_WriteReg(MCP_OLATB, 0x07);         // row output HIGH ก่อน
	    return ret;
}

void LCD_SendNibble(uint8_t data, uint8_t rs) {
	uint8_t buf = (data & 0xF0) | 0x08 | (rs ? 0x01 : 0x00);
	buf |= 0x04;
	HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
	buf &= ~0x04;
	HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
}

void LCD_SendCmd(uint8_t cmd) {
	LCD_SendNibble(cmd & 0xF0, 0);
	LCD_SendNibble(cmd << 4, 0);
	HAL_Delay(2);
}

void LCD_SendData(uint8_t data) {
	LCD_SendNibble(data & 0xF0, 1);
	LCD_SendNibble(data << 4, 1);
	HAL_Delay(2);
}

void LCD_Init(void) {
	HAL_Delay(50);
	LCD_SendNibble(0x30, 0);
	HAL_Delay(5);
	LCD_SendNibble(0x30, 0);
	HAL_Delay(1);
	LCD_SendNibble(0x30, 0);
	HAL_Delay(1);
	LCD_SendNibble(0x20, 0);
	HAL_Delay(1);
	LCD_SendCmd(0x28); // 4-bit, 2 line
	LCD_SendCmd(0x0C); // display on
	LCD_SendCmd(0x06); // entry mode
	LCD_SendCmd(0x01); // clear
	HAL_Delay(2);
}

void LCD_Clear(void) {
	LCD_SendCmd(0x01);
	HAL_Delay(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
	uint8_t addr[] = { 0x00, 0x40, 0x14, 0x54 };
	LCD_SendCmd(0x80 | (addr[row] + col));
}

void LCD_Print(char *str) {
	while (*str)
		LCD_SendData(*str++);
}

void LCD_UpdateAll(void) {
	char buf[21];
	int cur_int = (int) current_angle;
	int cur_dec = (int) ((current_angle - cur_int) * 10);
	int set_int = (int) set_angle;
	int set_dec = (int) ((set_angle - set_int) * 10);

	// Row 0: Mode + Emergency
	LCD_SetCursor(0, 0);
	sprintf(buf, "MODE:%-6s EMG:%-3s",
			robot_mode == MODE_AUTO ? "AUTO" : "MANUAL",
			emg_status == EMG_ON ? "ON " : "OFF");
	LCD_Print(buf);

	// Row 1: Current angle
	LCD_SetCursor(1, 0);
	sprintf(buf, "Cur:%4d.%1d deg  ", cur_int, cur_dec);
	LCD_Print(buf);

	// Row 2: Set angle
	LCD_SetCursor(2, 0);
	sprintf(buf, "Set:%4d.%1d deg  ", set_int, set_dec);
	LCD_Print(buf);

	// Row 3: Sent status
	LCD_SetCursor(3, 0);
	sprintf(buf, "Fuck u ja");
	LCD_Print(buf);
	if (angle_sent) {
		LCD_Print("             SENT!");
	} else {
		LCD_Print("                  ");
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
