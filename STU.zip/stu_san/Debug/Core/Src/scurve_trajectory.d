Core/Src/scurve_trajectory.o: ../Core/Src/scurve_trajectory.c \
 ../Core/Inc/scurve_trajectory.h
../Core/Inc/scurve_trajectory.h:
