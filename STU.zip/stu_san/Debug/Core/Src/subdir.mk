################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/Button_Matrix.c \
../Core/Src/Gripper.c \
../Core/Src/Joystick.c \
../Core/Src/LCD.c \
../Core/Src/Modbus.c \
../Core/Src/Mode.c \
../Core/Src/Rotary_encoder.c \
../Core/Src/main.c \
../Core/Src/proximity.c \
../Core/Src/robot_arm.c \
../Core/Src/scurve_trajectory.c \
../Core/Src/stm32g4xx_hal_msp.c \
../Core/Src/stm32g4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32g4xx.c 

OBJS += \
./Core/Src/Button_Matrix.o \
./Core/Src/Gripper.o \
./Core/Src/Joystick.o \
./Core/Src/LCD.o \
./Core/Src/Modbus.o \
./Core/Src/Mode.o \
./Core/Src/Rotary_encoder.o \
./Core/Src/main.o \
./Core/Src/proximity.o \
./Core/Src/robot_arm.o \
./Core/Src/scurve_trajectory.o \
./Core/Src/stm32g4xx_hal_msp.o \
./Core/Src/stm32g4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32g4xx.o 

C_DEPS += \
./Core/Src/Button_Matrix.d \
./Core/Src/Gripper.d \
./Core/Src/Joystick.d \
./Core/Src/LCD.d \
./Core/Src/Modbus.d \
./Core/Src/Mode.d \
./Core/Src/Rotary_encoder.d \
./Core/Src/main.d \
./Core/Src/proximity.d \
./Core/Src/robot_arm.d \
./Core/Src/scurve_trajectory.d \
./Core/Src/stm32g4xx_hal_msp.d \
./Core/Src/stm32g4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32g4xx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G474xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/Button_Matrix.cyclo ./Core/Src/Button_Matrix.d ./Core/Src/Button_Matrix.o ./Core/Src/Button_Matrix.su ./Core/Src/Gripper.cyclo ./Core/Src/Gripper.d ./Core/Src/Gripper.o ./Core/Src/Gripper.su ./Core/Src/Joystick.cyclo ./Core/Src/Joystick.d ./Core/Src/Joystick.o ./Core/Src/Joystick.su ./Core/Src/LCD.cyclo ./Core/Src/LCD.d ./Core/Src/LCD.o ./Core/Src/LCD.su ./Core/Src/Modbus.cyclo ./Core/Src/Modbus.d ./Core/Src/Modbus.o ./Core/Src/Modbus.su ./Core/Src/Mode.cyclo ./Core/Src/Mode.d ./Core/Src/Mode.o ./Core/Src/Mode.su ./Core/Src/Rotary_encoder.cyclo ./Core/Src/Rotary_encoder.d ./Core/Src/Rotary_encoder.o ./Core/Src/Rotary_encoder.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/proximity.cyclo ./Core/Src/proximity.d ./Core/Src/proximity.o ./Core/Src/proximity.su ./Core/Src/robot_arm.cyclo ./Core/Src/robot_arm.d ./Core/Src/robot_arm.o ./Core/Src/robot_arm.su ./Core/Src/scurve_trajectory.cyclo ./Core/Src/scurve_trajectory.d ./Core/Src/scurve_trajectory.o ./Core/Src/scurve_trajectory.su ./Core/Src/stm32g4xx_hal_msp.cyclo ./Core/Src/stm32g4xx_hal_msp.d ./Core/Src/stm32g4xx_hal_msp.o ./Core/Src/stm32g4xx_hal_msp.su ./Core/Src/stm32g4xx_it.cyclo ./Core/Src/stm32g4xx_it.d ./Core/Src/stm32g4xx_it.o ./Core/Src/stm32g4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32g4xx.cyclo ./Core/Src/system_stm32g4xx.d ./Core/Src/system_stm32g4xx.o ./Core/Src/system_stm32g4xx.su

.PHONY: clean-Core-2f-Src

