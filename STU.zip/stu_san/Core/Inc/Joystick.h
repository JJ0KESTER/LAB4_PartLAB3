/*
 * Joystick.h
 *
 *  Created on: May 30, 2026
 *      Author: nitro
 */

#ifndef INC_JOYSTICK_H_
#define INC_JOYSTICK_H_

#include <stdint.h>

/* Global variables for system monitoring in Live Expressions */
extern volatile float joystick_target_step;
extern volatile float joystick_resolution;
extern volatile float joystick_direction;
extern volatile float joystick_home_offset;
extern volatile uint8_t joystick_home_state;
extern volatile uint8_t joystick_sent_flag;

/* Public API */
void Joystick_Init(void);
void Joystick_Process(void);


#endif /* INC_JOYSTICK_H_ */
