#ifndef BUTTON_MATRIX_H
#define BUTTON_MATRIX_H

#include "main.h"

// MCP23017 registers
#define MCP23017_ADDR   (0x20 << 1)
#define MCP_IODIRA      0x00
#define MCP_IODIRB      0x01
#define MCP_GPPUB       0x0D
#define MCP_GPIOB       0x13
#define MCP_OLATA       0x14
#define MCP_OLATB       0x15

HAL_StatusTypeDef MCP_WriteReg(uint8_t reg, uint8_t data);
HAL_StatusTypeDef MCP_ReadReg(uint8_t reg, uint8_t *data);
HAL_StatusTypeDef MCP_Init(void);
char ButtonMatrix_Scan(void);

#endif
