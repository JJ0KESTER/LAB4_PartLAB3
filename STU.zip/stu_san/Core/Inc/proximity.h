#ifndef PROXIMITY_H
#define PROXIMITY_H

#include "stm32g4xx_hal.h"
#include <stdbool.h>

/* ── กำหนดขา GPIO สำหรับ Proximity Sensor ── */
//#define PROXIMITY1_PIN  GPIO_PIN_14
//#define PROXIMITY1_PORT GPIOC

#define PROXIMITY2_PIN  GPIO_PIN_0
#define PROXIMITY2_PORT GPIOB

/* ── ฟังก์ชันการใช้งาน ── */
void Proximity_Init(void);
//bool Proximity_Read_Sensor1(void);
void Proximity_Read_Sensor(void);

#endif /* PROXIMITY_H */
