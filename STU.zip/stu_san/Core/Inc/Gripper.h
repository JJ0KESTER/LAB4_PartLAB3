#ifndef GRIPPER_H
#define GRIPPER_H

#include <stdint.h>
#include "Modbus.h"
#include "stm32g4xx_hal.h" // จำเป็นต้อง include เพื่อใช้ GPIO

/* ── กำหนดขา GPIO สำหรับ Gripper Relay ── */
#define GRIPPER_UP_PIN      GPIO_PIN_2
#define GRIPPER_UP_PORT     GPIOB

#define GRIPPER_DOWN_PIN    GPIO_PIN_1
#define GRIPPER_DOWN_PORT   GPIOB

#define GRIPPER_OPEN_PIN    GPIO_PIN_14
#define GRIPPER_OPEN_PORT   GPIOB

#define GRIPPER_CLOSE_PIN   GPIO_PIN_15
#define GRIPPER_CLOSE_PORT  GPIOB

/* ── ตั้งค่า Active State (แก้ที่นี่หน้างานถ้าทำงานกลับด้าน) ── */
#define RELAY_ON            GPIO_PIN_SET    // เปลี่ยนเป็น GPIO_PIN_RESET ถ้าวงจร Relay เป็นแบบ Active Low
#define RELAY_OFF           GPIO_PIN_RESET  // เปลี่ยนเป็น GPIO_PIN_SET ถ้าวงจร Relay เป็นแบบ Active Low

void Gripper_Init(u16u8_t *reg_ptr);
void Gripper_InitHardware(void); // เพิ่มฟังก์ชันนี้สำหรับ init ขา GPIO

void Gripper_HandleManual(uint16_t bits);
void Gripper_HandleSequence(uint16_t bits);
void Gripper_HandleAuto(uint16_t bits);

void Gripper_MoveUp(void);
void Gripper_MoveDown(void);
void Gripper_Open(void);
void Gripper_Close(void);
void Gripper_DoPick(void);
void Gripper_DoPlace(void);
void Gripper_SetAutoMode(uint8_t enable);

#endif /* GRIPPER_H */
