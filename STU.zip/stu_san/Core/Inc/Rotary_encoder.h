/*
 * Rotary_encoder.h
 *
 *  Created on: May 1, 2026
 *      Author: nitro
 */

#ifndef INC_ROTARY_ENCODER_H_
#define INC_ROTARY_ENCODER_H_



#endif /* INC_ROTARY_ENCODER_H_ */
#ifndef ROTARY_ENCODER_H
#define ROTARY_ENCODER_H

#include "main.h"

#define ONE_TURN_QEI_CNT    840
#define MULTI_TURN_QEI_CNT  65520
#define OBSEVER_PERIOD      0.0002f  // 5kHz

typedef struct {
    uint32_t Position[2];
    float QEIPostion_1turn;
    float QEIAngularVelocity;
    float QEIAngularVelocity_MWA;
} QEI_StructureTypeDef;

extern QEI_StructureTypeDef QEIdata;

void QEIEncoderPosVel_Update(void);
float QEI_GetDegree(void);
float QEI_GetRadian(void);

#endif
