#ifndef LCD_H
#define LCD_H

#include "main.h"

#define LCD_ADDR    (0x27 << 1)

/* ป้องกันปัญหา Naming Conflict กับระบบ Modbus */
typedef enum { LCD_MODE_MANUAL, LCD_MODE_AUTO } RobotMode;
typedef enum { EMG_OFF, EMG_ON }       EmgStatus;

extern RobotMode robot_mode;
extern EmgStatus emg_status;
extern float     current_angle;
extern float     set_angle;
extern uint8_t   angle_sent;

void LCD_Init(void);
void LCD_Clear(void);
void LCD_SetCursor(uint8_t row, uint8_t col);
void LCD_Print(char *str);

/* ประกังก์ชันตัวกระจายสตรีมชุดใหม่เข้าพอร์ตงานหลัก */
void LCD_UpdateAll(void);
//void LCD_Buffer_Stream_Tick(void);
void LCD_UpdateLine_NonBlocking(void);
void LCD_SendCmd(uint8_t cmd);
void LCD_SendData(uint8_t data);

#endif
