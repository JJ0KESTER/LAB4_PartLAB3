#ifndef MODE_H
#define MODE_H

/* ════════════════════════════════════════════════════════════════════════════
 * Mode.h — Robot mode handler declarations
 * ════════════════════════════════════════════════════════════════════════════
 */

#include <stdint.h>
#include "scurve_trajectory.h"
#include "Modbus.h"

/* ── Robot mode enum ─────────────────────────────────────────────────────── */
typedef enum {
    ROBOT_IDLE = 0,
    ROBOT_GOHOME,
    ROBOT_JOG,
    ROBOT_AUTO,
    ROBOT_SET_HOME,
    ROBOT_TEST,
} RobotMode_t;

/* ── Test sub-phase enum ─────────────────────────────────────────────────── */
typedef enum {
    TEST_IDLE    = 0,
    TEST_RUNNING,
    TEST_DONE,
} TestPhase_t;

/* ── Shared state (defined in Mode.c, readable by main.c) ───────────────── */
extern volatile float       real_position_deg;
extern volatile float       real_velocity;
extern volatile float       real_accel;
extern volatile float       sim_position_deg;
extern volatile uint8_t     sim_enable;
extern volatile RobotMode_t current_mode;
extern SCurveTraj_t         g_traj;

/* ── Public API ──────────────────────────────────────────────────────────── */

/** เริ่มต้น module — ส่ง pointer ของ reg[] จาก main.c เข้ามา */
void Mode_Init(u16u8_t *reg_ptr);

/** เรียกทุกรอบ main loop: decode REG_MODE → dispatch handler */
void Mode_Update(void);

/** เรียกทุกรอบ main loop: เขียน position/velocity/accel กลับ register */
void Mode_UpdateFeedback(void);

/** เรียกใน HAL_TIM_PeriodElapsedCallback (TIM6 ISR) */
void Mode_TrajTick(void);

#endif /* MODE_H */
