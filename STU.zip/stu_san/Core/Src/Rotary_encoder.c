/*
 * Rotary_encoder.c
 *
 *  Created on: May 1, 2026
 *      Author: nitro
 */
#include "rotary_encoder.h"

extern TIM_HandleTypeDef htim3;

QEI_StructureTypeDef QEIdata = {0};

enum { NEW, OLD };

void QEIEncoderPosVel_Update(void) {
    // collect data
    QEIdata.Position[NEW] = __HAL_TIM_GET_COUNTER(&htim3);

    // Position 1 turn
    QEIdata.QEIPostion_1turn = QEIdata.Position[NEW] % ONE_TURN_QEI_CNT;

    // dx
    int32_t diffPosition = QEIdata.Position[NEW] - QEIdata.Position[OLD];

    // Handle wrap around
    if (diffPosition > (MULTI_TURN_QEI_CNT / 2))
        diffPosition -= MULTI_TURN_QEI_CNT;
    else if (diffPosition < -(MULTI_TURN_QEI_CNT / 2))
        diffPosition += MULTI_TURN_QEI_CNT;

    // Angular velocity
    QEIdata.QEIAngularVelocity = (float)diffPosition / OBSEVER_PERIOD;
    QEIdata.QEIAngularVelocity_MWA = (QEIdata.QEIAngularVelocity
            + QEIdata.QEIAngularVelocity_MWA * 99) / 100.0f;

    QEIdata.Position[OLD] = QEIdata.Position[NEW];
}

float QEI_GetDegree(void) {
    return (__HAL_TIM_GET_COUNTER(&htim3) / (float)ONE_TURN_QEI_CNT) * 360.0f;
}

float QEI_GetRadian(void) {
    return (__HAL_TIM_GET_COUNTER(&htim3) / (float)ONE_TURN_QEI_CNT) * (2.0f * 3.14159265f);
}

