/*
 * Button_Matrix.c
 *
 *  Created on: May 1, 2026
 *      Author: nitro
 */
#include "button_matrix.h"

extern I2C_HandleTypeDef hi2c1;

static const char keymap[3][3] = {
    {'1','2','3'},
    {'4','5','6'},
    {'7','8','9'}
};

HAL_StatusTypeDef MCP_WriteReg(uint8_t reg, uint8_t data) {
    return HAL_I2C_Mem_Write(&hi2c1, MCP23017_ADDR, reg,
                              I2C_MEMADD_SIZE_8BIT, &data, 1, 100);
}

HAL_StatusTypeDef MCP_ReadReg(uint8_t reg, uint8_t *data) {
    return HAL_I2C_Mem_Read(&hi2c1, MCP23017_ADDR, reg,
                             I2C_MEMADD_SIZE_8BIT, data, 1, 100);
}

HAL_StatusTypeDef MCP_Init(void) {
    HAL_StatusTypeDef ret;

    ret = MCP_WriteReg(0x0A, 0x00);         // IOCON reset
    if (ret != HAL_OK) return ret;

    ret = MCP_WriteReg(MCP_IODIRB, 0x38);   // bit3-5 input, bit0-2 output
    if (ret != HAL_OK) return ret;

    ret = MCP_WriteReg(MCP_GPPUB, 0x38);    // pull-up bit3-5
    if (ret != HAL_OK) return ret;

    ret = MCP_WriteReg(MCP_OLATB, 0x07);    // row HIGH
    return ret;
}

char ButtonMatrix_Scan(void) {
    uint8_t port_data;

    for (uint8_t row = 0; row < 3; row++) {
        uint8_t row_mask = ~(1 << row) & 0x07;
        MCP_WriteReg(MCP_OLATB, row_mask);
        HAL_Delay(1);

        MCP_ReadReg(MCP_GPIOB, &port_data);
        uint8_t col_data = (port_data >> 3) & 0x07;

        if (col_data != 0x07) {
            for (uint8_t col = 0; col < 3; col++) {
                if (!(col_data & (1 << col))) {
                    MCP_WriteReg(MCP_OLATB, 0x07);
                    return keymap[row][col];
                }
            }
        }
    }

    MCP_WriteReg(MCP_OLATB, 0x07);
    return 0;
}

