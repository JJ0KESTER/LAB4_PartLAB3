#include "LCD.h"
#include "main.h"
#include "Mode.h"
#include "robot_arm.h"
#include <math.h>
#include <stdio.h>

extern I2C_HandleTypeDef hi2c1;
extern RobotArm_t g_arm;
extern u16u8_t reg[MODBUS_REGISTER_COUNT];

extern volatile float joystick_target_step;
extern volatile float joystick_direction;
extern volatile uint8_t joystick_sent_flag;

/* ─── 1. ฟังก์ชันพื้นฐานสำหรับส่งข้อมูลผ่าน I2C ─── */
void LCD_SendNibble(uint8_t data, uint8_t rs) {
    uint8_t buf = (data & 0xF0) | 0x08 | (rs ? 0x01 : 0x00);
    buf |= 0x04;  HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
    buf &= ~0x04; HAL_I2C_Master_Transmit(&hi2c1, LCD_ADDR, &buf, 1, 100);
}

void LCD_SendCmd(uint8_t cmd) {
    LCD_SendNibble(cmd & 0xF0, 0);
    LCD_SendNibble(cmd << 4,   0);
}

void LCD_SendData(uint8_t data) {
    LCD_SendNibble(data & 0xF0, 1);
    LCD_SendNibble(data << 4,   1);
}

void LCD_Init(void) {
    HAL_Delay(50);
    LCD_SendNibble(0x30, 0); HAL_Delay(5);
    LCD_SendNibble(0x30, 0); HAL_Delay(1);
    LCD_SendNibble(0x30, 0); HAL_Delay(1);
    LCD_SendNibble(0x20, 0); HAL_Delay(1);

    LCD_SendCmd(0x28); // 4-bit, 2 line
    LCD_SendCmd(0x0C); // display on
    LCD_SendCmd(0x06); // entry mode
    LCD_SendCmd(0x01); // clear
    HAL_Delay(2);
}

void LCD_Clear(void) {
    LCD_SendCmd(0x01);
    HAL_Delay(2);
}

void LCD_SetCursor(uint8_t row, uint8_t col) {
    uint8_t addr[] = {0x00, 0x40, 0x14, 0x54};
    LCD_SendCmd(0x80 | (addr[row] + col));
}

void LCD_Print(char *str) {
    while (*str) {
        LCD_SendData(*str++);
    }
}


/* ─── 2. ระบบสลับอัปเดตหน้าจอทีละบรรทัด (ป้องกัน Modbus ค้าง) ─── */
static uint8_t current_lcd_row = 0;

void LCD_UpdateLine_NonBlocking(void) {
    char buf[21];

    // ตั้งเคอร์เซอร์ไปที่บรรทัดของรอบปัจจุบัน
    LCD_SetCursor(current_lcd_row, 0);

    if (current_lcd_row == 0) {
        // แถวที่ 0: โหมดและสถานะฉุกเฉิน
        const char* mode_name = "IDLE";
        if (current_mode == ROBOT_GOHOME)  mode_name = "HOME";
        if (current_mode == ROBOT_JOG)     mode_name = "JOG ";
        if (current_mode == ROBOT_AUTO)    mode_name = "AUTO";
        if (current_mode == ROBOT_TEST)    mode_name = "TEST";
        uint8_t emg_active = (reg[0x31].U16 & 0x0001);

        sprintf(buf, "M:%s  EMG:%s  ", mode_name, emg_active ? "TRIP" : "OK  ");
        LCD_Print(buf);
    }
    else if (current_lcd_row == 1) {
        // แถวที่ 1: ตำแหน่งองศาจริง
        int32_t cur_int = (int32_t)g_arm.pos_deg;
        int32_t cur_dec = (int32_t)(fabsf(g_arm.pos_deg) * 10.0f) % 10;

        sprintf(buf, "Robot:%4ld.%1ld deg  ", cur_int, cur_dec);
        LCD_Print(buf);
    }
    else if (current_lcd_row == 2) {
        // แถวที่ 2: ค่าเตรียมส่งจาก Joystick
        int32_t set_int = (int32_t)joystick_target_step;
        int32_t set_dec = (int32_t)(joystick_target_step * 10.0f) % 10;
        char dir_char = (joystick_direction >= 0.0f) ? '+' : '-';

        sprintf(buf, "Next :%c%3ld.%1ld deg  ", dir_char, set_int, set_dec);
        LCD_Print(buf);
    }
    else if (current_lcd_row == 3) {
        // แถวที่ 3: สถานะการส่งคำสั่ง
        if (joystick_sent_flag == 1)      sprintf(buf, "Status: TX SUCCESS  ");
        else if (joystick_sent_flag == 2) sprintf(buf, "Status: GO HOME...  ");
        else                              sprintf(buf, "Status: STANDBY     ");

        LCD_Print(buf);
    }

    // สลับไปยังบรรทัดถัดไปในรอบเวลาหน้า (0 -> 1 -> 2 -> 3 -> 0)
    current_lcd_row++;
    if (current_lcd_row > 3) {
        current_lcd_row = 0;
    }
}
