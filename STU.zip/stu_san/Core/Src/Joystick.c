/*
 * Joystick.c
 *
 *  Created on: May 30, 2026
 *      Author: nitro
 */

#include "Joystick.h"
#include "main.h"
#include "Button_Matrix.h"
#include "Rotary_encoder.h"
#include "robot_arm.h"
#include "Gripper.h"
#include "Mode.h"
#include <math.h>

extern TIM_HandleTypeDef htim3;
extern RobotArm_t g_arm;
extern u16u8_t reg[MODBUS_REGISTER_COUNT];

volatile float joystick_target_step = 0.0f;
volatile float joystick_resolution = 1.0f;
volatile float joystick_direction = 1.0f;
volatile float joystick_home_offset = 0.0f;
volatile uint8_t joystick_home_state = 0;
volatile uint8_t joystick_sent_flag = 0;
static uint32_t joystick_sent_tick = 0;

void Joystick_Init(void) {
    MCP_Init();
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
    __HAL_TIM_SET_COUNTER(&htim3, 0);
}

void Joystick_Process(void) {
    /* Joystick is strictly authorized to operate ONLY during ROBOT_JOG mode */
    if (current_mode != ROBOT_JOG) {
        return;
    }

    char key = ButtonMatrix_Scan();

    if (key == '1') {
        joystick_direction = (joystick_direction >= 0.0f) ? -1.0f : 1.0f;
    }
    else if (key == '2') {
        if (joystick_home_state == 0) {
            joystick_home_offset = joystick_target_step * joystick_direction;
            joystick_home_state = 1;
            joystick_sent_flag = 1;
            joystick_sent_tick = HAL_GetTick();
        } else {
            RobotArm_Stop(&g_arm);
            float diff = joystick_home_offset - g_arm.pos_deg;
            float move_deg = fabsf(diff);
            float move_dir = (diff >= 0.0f) ? 1.0f : -1.0f;
            if (move_deg > 0.0f) {
                RobotArm_Move(&g_arm, move_deg, move_dir);
            }
            joystick_home_state = 0;
            joystick_sent_flag = 2;
            joystick_sent_tick = HAL_GetTick();
        }
    }
    else if (key == '3') {
        Gripper_DoPlace();
    }
    else if (key == '4') {
        joystick_resolution = 45.0f;
    }
    else if (key == '5') {
        joystick_resolution = 1.0f;
    }
    else if (key == '6') {
        joystick_resolution = 0.1f;
    }
    else if (key == '7') {
        Gripper_DoPick();
    }
    else if (key == '8') {
        reg[REG_GRIPPER_MANUAL].U16 = 0x0004;
        Gripper_HandleManual(0x0004);
    }
    else if (key == '9') {
        reg[REG_GRIPPER_MANUAL].U16 = 0x0008;
        Gripper_HandleManual(0x0008);
    }

    /* Track Handheld Rotary Encoder pulses change vector */
    int16_t encoder_diff = (int16_t)__HAL_TIM_GET_COUNTER(&htim3);
    if (encoder_diff != 0) {
        __HAL_TIM_SET_COUNTER(&htim3, 0);
        joystick_target_step += ((float)encoder_diff) * joystick_resolution;
        if (joystick_target_step < 0.0f) {
            joystick_target_step = 0.0f;
        }
    }

    /* Check center switch execution confirmation (PA7 Input Pull-Up) */
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_RESET) {
        HAL_Delay(50); /* Debounce filtering */
        if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_RESET) {
            while (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_RESET);

            RobotArm_Stop(&g_arm);
            if (joystick_target_step > 0.0f) {
                RobotArm_Move(&g_arm, joystick_target_step, joystick_direction);
                joystick_sent_flag = 1;
                joystick_sent_tick = HAL_GetTick();
            }
        }
    }

    /* Clear visual handshake message state after 1.5 seconds */
    if (joystick_sent_flag != 0 && (HAL_GetTick() - joystick_sent_tick) > 1500) {
        joystick_sent_flag = 0;
    }
}
