#include "Gripper.h"
#include "main.h"
#include <stdio.h>

/* ── Static pointer to reg[] (set by Gripper_Init) ───────────────────────── */
static u16u8_t *R = NULL;
extern volatile check;

void Gripper_Init(u16u8_t *reg_ptr)
{
    R = reg_ptr;
}

/* กรณีไม่ได้ตั้งค่า GPIO ผ่าน CubeMX ให้เรียกใช้ฟังก์ชันนี้ */
void Gripper_InitHardware(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOB_CLK_ENABLE();

    /* เซ็ตค่าเริ่มต้นให้ Relay ทั้งหมด OFF */
    HAL_GPIO_WritePin(GPIOB, GRIPPER_UP_PIN | GRIPPER_DOWN_PIN | GRIPPER_OPEN_PIN | GRIPPER_CLOSE_PIN, RELAY_OFF);

    GPIO_InitStruct.Pin = GRIPPER_UP_PIN | GRIPPER_DOWN_PIN | GRIPPER_OPEN_PIN | GRIPPER_CLOSE_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}

/* ── Low-level stubs พร้อมระบบ Debug ─────────────────────────────────────── */
void Gripper_MoveUp(void)
{
//	check = 100;
//    printf("[GRIPPER] Action: Move UP requested.\r\n");
    HAL_GPIO_WritePin(GRIPPER_DOWN_PORT, GRIPPER_DOWN_PIN, RELAY_OFF); // ดับ Down ก่อนเพื่อความปลอดภัย
    HAL_GPIO_WritePin(GRIPPER_UP_PORT, GRIPPER_UP_PIN, RELAY_ON);
}

void Gripper_MoveDown(void)
{
//    printf("[GRIPPER] Action: Move DOWN requested.\r\n");
    HAL_GPIO_WritePin(GRIPPER_UP_PORT, GRIPPER_UP_PIN, RELAY_OFF);     // ดับ Up ก่อน
    HAL_GPIO_WritePin(GRIPPER_DOWN_PORT, GRIPPER_DOWN_PIN, RELAY_ON);
}

void Gripper_Open(void)
{
//    printf("[GRIPPER] Action: OPEN requested.\r\n");
    HAL_GPIO_WritePin(GRIPPER_CLOSE_PORT, GRIPPER_CLOSE_PIN, RELAY_OFF); // ดับ Close ก่อน
    HAL_GPIO_WritePin(GRIPPER_OPEN_PORT, GRIPPER_OPEN_PIN, RELAY_ON);
}

void Gripper_Close(void)
{
//    printf("[GRIPPER] Action: CLOSE requested.\r\n");
    HAL_GPIO_WritePin(GRIPPER_OPEN_PORT, GRIPPER_OPEN_PIN, RELAY_OFF);   // ดับ Open ก่อน
    HAL_GPIO_WritePin(GRIPPER_CLOSE_PORT, GRIPPER_CLOSE_PIN, RELAY_ON);
}

void Gripper_DoPick(void)
{
//    printf("[GRIPPER] Sequence: Start Pick Process (Down -> Close -> Up)\r\n");
    Gripper_MoveDown();
    HAL_Delay(500);
    Gripper_Close();
    HAL_Delay(500);
    Gripper_MoveUp();
//    printf("[GRIPPER] Sequence: End Pick Process\r\n");
}

void Gripper_DoPlace(void)
{
//    printf("[GRIPPER] Sequence: Start Place Process (Down -> Open -> Up)\r\n");
    Gripper_MoveDown();
    HAL_Delay(500);
    Gripper_Open();
    HAL_Delay(500);
    Gripper_MoveUp();
//    printf("[GRIPPER] Sequence: End Place Process\r\n");
}

void Gripper_SetAutoMode(uint8_t enable)
{
    if (enable) {
//        printf("[GRIPPER] Auto Mode: ENABLED\r\n");
        Gripper_DoPick();
        HAL_Delay(1000);
        Gripper_DoPlace();
    } else {
//        printf("[GRIPPER] Auto Mode: DISABLED\r\n");
    }
    /* TODO: Implement Logic เพิ่มเติมสำหรับ Auto mode ถ้ามี */
}

/* ── Register-level handlers (เชื่อมต่อลอจิกจาก Modbus) ────────────────────── */
void Gripper_HandleManual(uint16_t bits)
{
	check = 666;
//    if (bits == 0) return; // ไม่มีบิตไหนสั่งงาน ไม่ต้องทำอะไร

//    printf("[MODBUS RX] Gripper Manual Command Bits: 0x%04X\r\n", bits);
    if (bits == 0x0000) {Gripper_MoveUp(); check = 101;}
    if (bits == 0x0001) {Gripper_MoveDown(); check = 102;}
    if (bits == 0x0002) {Gripper_Open(); check = 103;}
    if (bits == 0x0004) {Gripper_Close(); check = 104;}
}

void Gripper_HandleSequence(uint16_t bits)
{
    if (bits == 0) return;

//    printf("[MODBUS RX] Gripper Sequence Command Bits: 0x%04X\r\n", bits);
    // Base System: Bit 1 (Value=2) คือ Go Pick, Bit 2 (Value=4) คือ Go Place
    if (bits & 0x0002) {
        Gripper_DoPick();
    }
    if (bits & 0x0004) {
        Gripper_DoPlace();
    }
}

void Gripper_HandleAuto(uint16_t bits)
{
//    printf("[MODBUS RX] Gripper Auto Enable Register Changed: 0x%04X\r\n", bits);
    // ส่งบิตแรกไปเซ็ตสเตตัส Auto Mode
    Gripper_SetAutoMode(bits & 0x0001);
}
