/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file    main.c
 * @brief   Robot Controller — Mode-based control via Modbus RTU
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "scurve_trajectory.h"
#include "Modbus.h"
#include "Mode.h"
#include "Gripper.h"
#include "proximity.h"
#include "robot_arm.h"
#include "Button_Matrix.h"
#include "LCD.h"
#include "Rotary_encoder.h"
#include "Joystick.h"
#include "CANBUS.h"
#include "kalman.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#define DEBOUNCE_MS     200U    /* ระยะเวลา debounce ปุ่ม B1 [ms] */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
FDCAN_HandleTypeDef hfdcan1;

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef hlpuart1;
DMA_HandleTypeDef hdma_lpuart1_rx;
DMA_HandleTypeDef hdma_lpuart1_tx;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim16;

/* USER CODE BEGIN PV */
ModbusHandleTypedef hmodbus;
u16u8_t reg[MODBUS_REGISTER_COUNT]; /* owner อยู่ที่นี่ที่เดียว */

volatile uint32_t uart_rx_count = 0;
volatile uint16_t dbg_rx_tail = 0;
volatile uint8_t dbg_crc_fail = 0;
volatile uint16_t dbg_crc_calc = 0;
volatile uint16_t dbg_crc_recv = 0;
volatile uint8_t dbg_tx_count = 0;
volatile uint8_t  dbg_mode_cleared_by = 0;
volatile uint16_t dbg_reg5_snap       = 0;
volatile uint32_t dbg_reg_ptr         = 0; /* address ของ reg[0] */
volatile uint8_t dbg_worker_state = 0;

extern volatile float joystick_target_step;
extern volatile float joystick_resolution;
extern volatile float joystick_direction;
extern volatile float joystick_home_offset;
extern volatile uint8_t joystick_home_state;
extern volatile uint8_t joystick_sent_flag;

RobotArm_t g_arm;
//int tar = 180;
extern volatile int check;

volatile int proximity = 0;
volatile int home_enable = 0;
extern int check_tickProx;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM6_Init(void);
static void MX_TIM16_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM7_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
static void MX_LPUART1_UART_Init(void);
static void MX_FDCAN1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM6_Init();
  MX_TIM16_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM7_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  MX_LPUART1_UART_Init();
  MX_FDCAN1_Init();
  /* USER CODE BEGIN 2 */
//  HAL_GPIO_WritePin(PROXIMITY1_PORT, PROXIMITY1_PIN, GPIO_PIN_SET);
	memset(reg, 0, sizeof(reg));
	reg[REG_HEARTBEAT].U16 = HEARTBEAT_ROBOT;

//	Modbus_init();
	hmodbus.huart = &hlpuart1;
	hmodbus.htim = &htim16;
	hmodbus.slaveAddress = MODBUS_SLAVE_ADDRESS;
	hmodbus.RegisterSize = MODBUS_REGISTER_COUNT;
	Modbus_init(&hmodbus, reg);
	dbg_reg_ptr = (uint32_t)&reg[0];

	Mode_Init(reg);
	Gripper_Init(reg);
	LCD_Init();
	Joystick_Init();
//	RobotArm_Init(&g_arm);

	Gripper_InitHardware();
//	Proximity_Init();
	RobotArm_Init(&g_arm); /* เริ่ม TIM1(PWM), TIM2(Encoder), TIM7(1kHz ISR) */
//	HAL_Delay(500);

	if (home_enable) {
		Proximity_Read_Sensor();
	}

//	// หยุด control loop ก่อน
//	HAL_TIM_Base_Stop_IT(&htim7);
//	CANBUS_Init(&hfdcan1);

//
//	__HAL_TIM_MOE_ENABLE(&htim1);
//	HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_RESET);
//	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 1000);
//	HAL_Delay(2000);
//	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
//	HAL_Delay(500);
//
//	// ทิศ -1
//	HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_RESET);
//	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 300);
//	HAL_Delay(2000);
//	__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);
//	HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_SET);
//			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);  // PWM 50%
//			HAL_Delay(2000);

//			HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_RESET);
//			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 500);
//			HAL_Delay(2000);
//	RobotArm_Move(&g_arm, 90.0f, 1.0f);

	HAL_TIM_Base_Start_IT(&htim6);
	HAL_TIM_Base_Start_IT(&htim7);

//	hmodbus.huart = &hlpuart1;
//	hmodbus.htim = &htim16;
//	hmodbus.slaveAddress = MODBUS_SLAVE_ADDRESS;
//	hmodbus.RegisterSize = MODBUS_REGISTER_COUNT;
//	Modbus_init(&hmodbus, reg);

//	uint32_t refresh_lcd_ram_tick = 0;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
//		CANBUS_Process();
		proximity = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
//		if (proximity == 1 && !g_arm.done) {
//			/* เจอ sensor ระหว่างหมุน → หยุด + reset pos = 0 */
//			RobotArm_Stop(&g_arm);
//			g_arm.encoder_raw   = 0;
//			g_arm.encoder_last  = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
//			g_arm.pos_deg       = 0.0f;
//			g_arm.ref_pos_deg   = 0.0f;
//			g_arm.vel_deg_s     = 0.0f;
//			g_arm.kf.x[0]       = 0.0f;
//			g_arm.kf.x[1]       = 0.0f;
//			check = 11111;
//		}

//		if (home_enable == 1) {
//			Proximity_Read_Sensor();
//			}
		/* 1. Modbus */
		Modbus_Protocal_Worker();

		/* capture jog command ทันทีหลัง Modbus — ก่อน Mode_Jog จะ clear */
		dbg_reg5_snap = reg[REG_JOG].U16;
		if (dbg_reg5_snap != 0) {
			modbus_jog_latch = (int16_t)dbg_reg5_snap;
			reg[REG_JOG].U16 = 0;   /* clear register ที่นี่ ไม่ใช่ใน Mode_Jog */
		}

		/* 2. Heartbeat */
		if (reg[REG_HEARTBEAT].U16 == HEARTBEAT_PC)
			reg[REG_HEARTBEAT].U16 = HEARTBEAT_ROBOT;

		/* 3. Emergency */
//		if (HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin) == GPIO_PIN_RESET) { // ตัวอย่างดักจากปุ่มกดบนบอร์ด
//			reg[REG_EMERGENCY].U16 = 0x0001;
//		}

		if (reg[REG_EMERGENCY].U16 & 0x0001) {
			dbg_mode_cleared_by = 1;
			RobotArm_Stop(&g_arm);
			g_traj.active = false;
			current_mode = ROBOT_IDLE;
			reg[REG_TASK].U16 = 0x0000;
			reg[REG_MODE].U16 = 0x0000;
			reg[REG_EMERGENCY].U16 = 0x0000;
		}

		/* 4. Soft Stop (คำสั่งหยุดจาก Web UI) */
		if (reg[REG_SOFT_STOP].U16 & 0x0001) {
			dbg_mode_cleared_by = 2;
			RobotArm_Stop(&g_arm);
			g_traj.active = false;
			current_mode = ROBOT_IDLE;
			reg[REG_TASK].U16 = 0x0000;
			reg[REG_MODE].U16 = 0x0000;
			reg[REG_SOFT_STOP].U16 = 0x0000;
		}

		/* 5. Gripper Manual — detect การเปลี่ยนค่า รองรับ UP (0x0000) ด้วย */
		{
			static uint16_t last_gripper_cmd = 0;
			uint16_t cur = reg[REG_GRIPPER_MANUAL].U16;
			if (cur != last_gripper_cmd && reg[REG_MODE].U16 == 0x0002) {
				last_gripper_cmd = cur;
				Gripper_HandleManual(cur);
			}
		}

		/* 6. Gripper Sequence */
		if (reg[REG_GRIPPER_SEQ].U16) {
			Gripper_HandleSequence(reg[REG_GRIPPER_SEQ].U16);
			reg[REG_GRIPPER_SEQ].U16 = 0x0000;
		}

//		if (HAL_GetTick() - joystick_tick >= 50) {
//			joystick_tick = HAL_GetTick();
//			Joystick_Process();
//		}

		/* 7. Gripper Auto */
//		Gripper_HandleAuto(reg[REG_GRIPPER_AUTO_EN].U16);

		/* 8-9. Mode decode + execute */
		Mode_Update();


		/* 10. Feedback */
//		Mode_UpdateFeedback();
//		if (HAL_GetTick() - refresh_lcd_ram_tick >= 200) {
//			refresh_lcd_ram_tick = HAL_GetTick();
//			LCD_UpdateLine_NonBlocking();
//		}

//		static uint32_t lcd_tick = 0;
//		    if (HAL_GetTick() - lcd_tick >= 50) { // ทุก 50ms อัปเดตจอ 1 บรรทัด
//		        lcd_tick = HAL_GetTick();
//
//		        // ส่งเฉพาะบรรทัดเดียว (ห้ามเรียก LCD_UpdateAll ทั้งหมดในครั้งเดียว)
//		        // สร้างฟังก์ชัน LCD_UpdateLine(row) ขึ้นมา
//		        LCD_UpdateLine_NonBlocking();
//		    }

	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief FDCAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_FDCAN1_Init(void)
{

  /* USER CODE BEGIN FDCAN1_Init 0 */

  /* USER CODE END FDCAN1_Init 0 */

  /* USER CODE BEGIN FDCAN1_Init 1 */

  /* USER CODE END FDCAN1_Init 1 */
  hfdcan1.Instance = FDCAN1;
  hfdcan1.Init.ClockDivider = FDCAN_CLOCK_DIV1;
  hfdcan1.Init.FrameFormat = FDCAN_FRAME_CLASSIC;
  hfdcan1.Init.Mode = FDCAN_MODE_NORMAL;
  hfdcan1.Init.AutoRetransmission = DISABLE;
  hfdcan1.Init.TransmitPause = DISABLE;
  hfdcan1.Init.ProtocolException = DISABLE;
  hfdcan1.Init.NominalPrescaler = 34;
  hfdcan1.Init.NominalSyncJumpWidth = 1;
  hfdcan1.Init.NominalTimeSeg1 = 7;
  hfdcan1.Init.NominalTimeSeg2 = 2;
  hfdcan1.Init.DataPrescaler = 1;
  hfdcan1.Init.DataSyncJumpWidth = 1;
  hfdcan1.Init.DataTimeSeg1 = 1;
  hfdcan1.Init.DataTimeSeg2 = 1;
  hfdcan1.Init.StdFiltersNbr = 1;  /* ต้องมีอย่างน้อย 1 เพื่อใช้ ConfigFilter */
  hfdcan1.Init.ExtFiltersNbr = 0;
  hfdcan1.Init.TxFifoQueueMode = FDCAN_TX_FIFO_OPERATION;
  if (HAL_FDCAN_Init(&hfdcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN FDCAN1_Init 2 */
  HAL_NVIC_SetPriority(FDCAN1_IT0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(FDCAN1_IT0_IRQn);
  /* USER CODE END FDCAN1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x40B285C2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief LPUART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPUART1_UART_Init(void)
{

  /* USER CODE BEGIN LPUART1_Init 0 */

  /* USER CODE END LPUART1_Init 0 */

  /* USER CODE BEGIN LPUART1_Init 1 */

  /* USER CODE END LPUART1_Init 1 */
  hlpuart1.Instance = LPUART1;
  hlpuart1.Init.BaudRate = 19200;
  hlpuart1.Init.WordLength = UART_WORDLENGTH_9B;
  hlpuart1.Init.StopBits = UART_STOPBITS_1;
  hlpuart1.Init.Parity = UART_PARITY_EVEN;
  hlpuart1.Init.Mode = UART_MODE_TX_RX;
  hlpuart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  hlpuart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  hlpuart1.Init.ClockPrescaler = UART_PRESCALER_DIV8;
  hlpuart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&hlpuart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&hlpuart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&hlpuart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPUART1_Init 2 */

  /* USER CODE END LPUART1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 8499;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65535;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI12;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_Encoder_InitTypeDef sConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
  sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC1Filter = 0;
  sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
  sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
  sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
  sConfig.IC2Filter = 0;
  if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 169;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 169;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 999;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief TIM16 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM16_Init(void)
{

  /* USER CODE BEGIN TIM16_Init 0 */

  /* USER CODE END TIM16_Init 0 */

  /* USER CODE BEGIN TIM16_Init 1 */

  /* USER CODE END TIM16_Init 1 */
  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 169;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 1145;
  htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim16.Init.RepetitionCounter = 0;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OnePulse_Init(&htim16, TIM_OPMODE_SINGLE) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM16_Init 2 */

  /* USER CODE END TIM16_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_14|GPIO_PIN_15
                          |MOTOR_DIR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin PA9 */
  GPIO_InitStruct.Pin = LD2_Pin|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PressRotaryEncoder_Pin */
  GPIO_InitStruct.Pin = PressRotaryEncoder_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(PressRotaryEncoder_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB2 PB14 PB15
                           MOTOR_DIR_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_14|GPIO_PIN_15
                          |MOTOR_DIR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
	if (htim->Instance == TIM7) {
			RobotArm_ControlTick(&g_arm);
			Mode_UpdateFeedback();

			if (home_enable && (!RobotArm_IsDone(&g_arm)) && HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 1) {
					check_tickProx = 0;
					__disable_irq();
					RobotArm_Stop(&g_arm);
					/* รีเซ็ตตำแหน่งให้ครบ: encoder + Kalman + ref */
//					g_arm.encoder_raw        = 0;
//					g_arm.encoder_last       = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
//					g_arm.pos_deg            = 0.0f;
//					g_arm.vel_deg_s          = 0.0f;
//					g_arm.ref_pos_deg        = 0.0f;
//					g_arm.ref_vel_deg_s      = 0.0f;
//					KalmanFilter_Init(&g_arm.kf);   /* reset Kalman state → ไม่ overwrite pos กลับ */
					__enable_irq();

					g_arm.ref_pos_deg        = 0.0f;
					g_arm.pos_deg            = 0.0f;
			    	check_tickProx = 1;
			    	home_enable = 0;
			    }
//			if (prox_homing_active && proximity == 1) {
//						/* เจอ sensor → หยุด, reset pos=0, ref=0, เสร็จสิ้น homing */
//						RobotArm_Stop(&g_arm);
//						g_arm.encoder_raw    = 0;
//						g_arm.encoder_last   = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
//						g_arm.pos_deg        = 0.0f;
//						g_arm.ref_pos_deg    = 0.0f;
//						g_arm.vel_deg_s      = 0.0f;
//						g_arm.ref_vel_deg_s  = 0.0f;
//						g_arm.kf.x[0]        = 0.0f;
//						g_arm.kf.x[1]        = 0.0f;
//						prox_homing_active   = 0;
//						check = 11111;
//					}
//		static uint16_t joy_scan_counter = 0;
//		joy_scan_counter++;
//		if (joy_scan_counter >= 50) {
//			joy_scan_counter = 0;
//			Joystick_Process();
//		}
//		static uint16_t lcd_stream_counter = 0;
//		lcd_stream_counter++;
//		if (lcd_stream_counter >= 2) {
//			lcd_stream_counter = 0;
//			LCD_Buffer_Stream_Tick();
//		}
//			check = 191;
//			if (sim_enable) {
//				g_arm.pos_deg = g_arm.ref_pos_deg;
//				g_arm.vel_deg_s = g_arm.ref_vel_deg_s;
//			}
		}
	else if (htim->Instance == TIM6) {
			Mode_TrajTick();
		}
}
//int _write(int file, char *ptr, int len) {
//	for (int i = 0; i < len; i++) {
//		ITM_SendChar(*ptr++);
//	}
//	return len;
//}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size) {
	uart_rx_count++;
	dbg_rx_tail = Size;
	if (Size == 0)
		return;
	hmodbus.modbusUartStructure.RxTail = Size;
	hmodbus.Flag_T15TimeOut = 1;
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	check = 303;
//	if (GPIO_Pin == GPIO_PIN_1) {
//		reg[REG_EMERGENCY].U16 = 0x0001; /* Trip Modbus Flag */
//		RobotArm_Stop(&g_arm);
//	}
  if (GPIO_Pin == GPIO_PIN_13)
  {
	check = 33;
    static uint32_t last_tick = 0U;
    uint32_t now = HAL_GetTick();
    if ((now - last_tick) < 200)
    {
      return;
    }
    last_tick = now;

//    / สั่งเดินเฉพาะตอนที่ arm ทำงานรอบก่อนหน้าเสร็จและหยุดนิ่งแล้ว /
    if (RobotArm_IsDone(&g_arm) && (current_mode == ROBOT_IDLE))
    {
//      / 1. สร้างตัวแปรจำทิศทาง (จะรันบรรทัดนี้แค่ครั้งแรกที่เปิดบอร์ด) /
      static float current_dir = 1.0f;


      RobotArm_Move(&g_arm, 90.0f, current_dir);


      current_dir = -current_dir;
    }
}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
