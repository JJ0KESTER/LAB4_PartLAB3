/**
 * @file    robot_arm.c
 * @brief   1-DOF Robot Arm Library — Implementation
 *          STM32 NUCLEO-G474RE
 */

#include "robot_arm.h"
#include "kalman.h"
#include "main.h"
#include <math.h>
#include <string.h>

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim7;

#define DEG_TO_COUNTS(d)  ((int32_t)((d) * ARM_PULSES_PER_REV / 360.0f))
#define COUNTS_TO_DEG(c)  ((float)(c) * 360.0f / (float)ARM_PULSES_PER_REV)
#define CLAMPF(x, lo, hi) ((x) < (lo) ? (lo) : ((x) > (hi) ? (hi) : (x)))
#define TIM2_PERIOD       65535

/* ─── Private: PID compute ──────────────────────────────────────────────── */
static float _PID_Compute(PIDState_t *pid,
                           float       error,
                           float       kp,
                           float       ki,
                           float       kd,
                           float       i_limit,
                           float       out_limit,
                           float       dt)
{
    float P = kp * error;

    pid->integral += error * dt;
    pid->integral  = CLAMPF(pid->integral, -i_limit, i_limit);
    float I = ki * pid->integral;

    float D = kd * (error - pid->prev_error) / dt;
    pid->prev_error = error;

    return CLAMPF(P + I + D, -out_limit, out_limit);
}

/* ─── Private: read encoder ─────────────────────────────────────────────── */
static void _Encoder_Update(RobotArm_t *arm, float dt)
{
    int32_t raw  = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
    int32_t diff = raw - arm->encoder_last;

    if (diff >  (TIM2_PERIOD / 2)) diff -= (TIM2_PERIOD + 1);
    if (diff < -(TIM2_PERIOD / 2)) diff += (TIM2_PERIOD + 1);

    arm->encoder_last  = raw;
    arm->encoder_raw  += diff;
    arm->pos_deg       = COUNTS_TO_DEG(arm->encoder_raw);

    float vel_raw  = COUNTS_TO_DEG(diff) / dt;
    arm->vel_deg_s = 0.1f * vel_raw + 0.9f * arm->vel_deg_s;
}

/* ─── Private: set motor PWM ────────────────────────────────────────────── */
static void _Motor_SetPWM(float pwm_cmd)
{
    pwm_cmd = CLAMPF(pwm_cmd, -ARM_PWM_MAX, ARM_PWM_MAX);

    if (pwm_cmd > 1.0f)
        pwm_cmd = ARM_PWM_DEADBAND + pwm_cmd * (ARM_PWM_MAX - ARM_PWM_DEADBAND) / ARM_PWM_MAX;
    else if (pwm_cmd < -1.0f)
        pwm_cmd = -(ARM_PWM_DEADBAND + (-pwm_cmd) * (ARM_PWM_MAX - ARM_PWM_DEADBAND) / ARM_PWM_MAX);
    else
        pwm_cmd = 0.0f;

#if ARM_MOTOR_DIR_INVERT
    pwm_cmd = -pwm_cmd;
#endif

    if (pwm_cmd >= 0.0f) {
        HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_SET);
    } else {
        HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_RESET);
        pwm_cmd = -pwm_cmd;
    }
    uint32_t ccr_val = (uint32_t)(pwm_cmd * 8.5075f);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, ccr_val);
}

/* ─── Private: reset PID ────────────────────────────────────────────────── */
static void _PID_Reset(PIDState_t *pid)
{
    pid->integral   = 0.0f;
    pid->prev_error = 0.0f;
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  PUBLIC API
 * ═══════════════════════════════════════════════════════════════════════════ */

void RobotArm_Init(RobotArm_t *arm)
{
    memset(arm, 0, sizeof(RobotArm_t));

    SCurve_Init(&arm->traj);

    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
    __HAL_TIM_MOE_ENABLE(&htim1);

    HAL_GPIO_WritePin(MOTOR_DIR_GPIO_Port, MOTOR_DIR_Pin, GPIO_PIN_RESET);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 0);

    arm->encoder_last = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);

    HAL_TIM_Base_Start_IT(&htim7);

    arm->running = false;
    arm->done    = true;

    KalmanFilter_Init(&arm->kf);
    arm->u_volt = 0.0f;

    arm->intended_target = 0.0f;
}

/* ─── RobotArm_Move ─────────────────────────────────────────────────────── */
void RobotArm_Move(RobotArm_t *arm, float degrees, float direction)
{
    if (degrees <= 0.0f) return;

    float dir   = (direction >= 0.0f) ? 1.0f : -1.0f;
    float q_end = arm->pos_deg + dir * degrees;

    _PID_Reset(&arm->pos_pid);
    _PID_Reset(&arm->vel_pid);

    /* Approach compensation */
    /* Backlash compensation ปิดไว้ — ทำให้หมุนสั้นๆ ย้อนทิศก่อนหยุด
       ถ้าต้องการความแม่นยำสูงค่อย enable กลับ */
    arm->needs_approach = false;
    SCurve_SetSegment(&arm->traj, arm->pos_deg, q_end);

    arm->running        = true;
    arm->done           = false;
    arm->move_time_ms   = 0;
    arm->settle_time_ms = 0;
}

/* ─── RobotArm_MoveEx — custom v_max / a_max (Test mode) ───────────────── */
void RobotArm_MoveEx(RobotArm_t *arm, float degrees, float direction,
                     float v_max, float a_max)
{
    if (degrees <= 0.0f) return;

    float dir     = (direction >= 0.0f) ? 1.0f : -1.0f;
    float q_start = arm->pos_deg;
    float q_end   = q_start + dir * degrees;

    arm->intended_target = q_end;

    _PID_Reset(&arm->pos_pid);
    _PID_Reset(&arm->vel_pid);

    SCurve_SetSegmentEx(&arm->traj, q_start, q_end, v_max, a_max);

    arm->running      = true;
    arm->done         = false;
    arm->move_time_ms = 0;
}

/* ─── RobotArm_IsDone ───────────────────────────────────────────────────── */
bool RobotArm_IsDone(const RobotArm_t *arm)
{
    return arm->done;
}

/* ─── RobotArm_Stop ─────────────────────────────────────────────────────── */
void RobotArm_Stop(RobotArm_t *arm)
{
    arm->running     = false;
    arm->done        = true;
    arm->manual_mode = false;   /* ออกจาก manual mode */
    arm->manual_pwm  = 0.0f;
    _PID_Reset(&arm->pos_pid);
    _PID_Reset(&arm->vel_pid);
    _Motor_SetPWM(0.0f);
    arm->u_volt = 0.0f;
}

void RobotArm_ResetTarget(RobotArm_t *arm)
{
    arm->intended_target = 0.0f;
}

/* ─── RobotArm_ResetPosition — ตำแหน่งปัจจุบัน → 0 ───────────────────── */
void RobotArm_ResetPosition(RobotArm_t *arm)
{
    arm->encoder_raw   = 0;
    arm->encoder_last  = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
    arm->pos_deg       = 0.0f;
    arm->vel_deg_s     = 0.0f;
    arm->ref_pos_deg   = 0.0f;
    arm->ref_vel_deg_s = 0.0f;
    arm->u_volt        = 0.0f;
    KalmanFilter_Init(&arm->kf);
}

/* ─── RobotArm_DriveRaw — manual PWM สำหรับ homing ────────────────────── */
void RobotArm_DriveRaw(RobotArm_t *arm, float pwm_pct, float direction)
{
    float dir = (direction >= 0.0f) ? 1.0f : -1.0f;
    arm->manual_pwm  = dir * fabsf(pwm_pct) * ARM_PWM_MAX;
    arm->manual_mode = true;
    arm->running     = true;
    arm->done        = false;
    _PID_Reset(&arm->pos_pid);
    _PID_Reset(&arm->vel_pid);
}

/* ─── RobotArm_ControlTick @ 1 kHz ─────────────────────────────────────── */
void RobotArm_ControlTick(RobotArm_t *arm)
{
    const float dt = TRAJ_DT;

    /* 1. Encoder */
    _Encoder_Update(arm, dt);

    /* 1b. Kalman Predict + Update */
    KalmanFilter_Predict(&arm->kf, arm->u_volt);
    KalmanFilter_Update(&arm->kf, arm->pos_deg);

    arm->pos_deg   = Kalman_GetPositionDeg(&arm->kf);
    arm->vel_deg_s = Kalman_GetVelocityDegS(&arm->kf);

    if (!arm->running) {
        _Motor_SetPWM(0.0f);
        arm->u_volt = 0.0f;
        return;
    }

    /* Manual PWM mode — ข้าม PID/SCurve ออก PWM ตรงๆ */
    if (arm->manual_mode) {
        _Motor_SetPWM(arm->manual_pwm);
        arm->u_volt = (arm->manual_pwm / ARM_PWM_MAX) * MOTOR_VSUPPLY;
        return;
    }

    arm->move_time_ms++;

    /* 2. S-Curve */
    TrajOutput_t ref   = SCurve_Update(&arm->traj);
    arm->ref_pos_deg   = ref.position_deg;
    arm->ref_vel_deg_s = ref.velocity_deg_s;

    /* 3. Outer loop (position → vel_cmd) @ 100Hz */
    static uint32_t outer_counter = 0;
    static float    vel_cmd_hold  = 0.0f;

    float dist_to_target = fabsf(arm->traj.q_end - arm->pos_deg);
    bool  fine_zone      = (dist_to_target <= ARM_FINE_THRESHOLD_DEG);

    static bool prev_fine_zone = false;
    if (fine_zone != prev_fine_zone) {
        _PID_Reset(&arm->pos_pid);
        _PID_Reset(&arm->vel_pid);
        vel_cmd_hold   = 0.0f;
        prev_fine_zone = fine_zone;

        if (fine_zone) {
            /* เข้า Fine Zone → restart S-Curve ด้วย V/A ที่ช้าลง
               จาก pos ปัจจุบัน → q_end เดิม                        */
            SCurve_SetSegmentEx(&arm->traj,
                                arm->pos_deg,
                                arm->traj.q_end,
                                ARM_FINE_V_MAX_DEG_S,
                                ARM_FINE_A_MAX_DEG_S2);
        }
    }

    float pos_kp = fine_zone ? ARM_POS_KP_FINE : ARM_POS_KP;
    float pos_ki = fine_zone ? ARM_POS_KI_FINE : ARM_POS_KI;
    float pos_kd = fine_zone ? ARM_POS_KD_FINE : ARM_POS_KD;

    float vel_kp = fine_zone ? ARM_VEL_KP_FINE : ARM_VEL_KP;
    float vel_ki = fine_zone ? ARM_VEL_KI_FINE : ARM_VEL_KI;
    float vel_kd = fine_zone ? ARM_VEL_KD_FINE : ARM_VEL_KD;

    outer_counter++;
    if (outer_counter >= ARM_OUTER_LOOP_DIV) {
        outer_counter = 0;
        float pos_error = arm->ref_pos_deg - arm->pos_deg;
        vel_cmd_hold = _PID_Compute(&arm->pos_pid, pos_error,
                                     pos_kp, pos_ki, pos_kd,
                                     ARM_POS_I_LIMIT, ARM_POS_OUT_LIMIT,
                                     dt * ARM_OUTER_LOOP_DIV);
    }

    /* 4. Inner Velocity PID @ 1kHz */
    float vel_error = vel_cmd_hold - arm->vel_deg_s;
    float pwm_pid   = _PID_Compute(&arm->vel_pid, vel_error,
                                    vel_kp, vel_ki, vel_kd,
                                    ARM_VEL_I_LIMIT, ARM_VEL_OUT_LIMIT, dt);

    /* 5. FF — แยก coefficient ตาม zone */
    float omega    = arm->ref_vel_deg_s * (3.14159f / 180.0f);
    float V_FF     = (MOTOR_KE * omega + MOTOR_B * omega) / MOTOR_EFF;
    float ff_scale = fine_zone ? ARM_FF_SCALE_FINE : ARM_FF_SCALE_NORMAL;
    float pwm_ff   = V_FF * ARM_PWM_MAX * ff_scale / MOTOR_VSUPPLY;
    float pwm_cmd = CLAMPF(pwm_pid + pwm_ff, -ARM_PWM_MAX, ARM_PWM_MAX);

    /* 6. Drive motor */
    _Motor_SetPWM(pwm_cmd);
    arm->u_volt = (pwm_cmd / ARM_PWM_MAX) * MOTOR_VSUPPLY;

    /* 7. Done check */
    if (SCurve_IsDone(&arm->traj)) {

        /* Phase 2: approach จากทิศที่ถูก */
        if (arm->needs_approach) {
            arm->needs_approach  = false;
            arm->settle_time_ms  = 0;
            _PID_Reset(&arm->pos_pid);
            _PID_Reset(&arm->vel_pid);
            SCurve_SetSegment(&arm->traj, arm->pos_deg, arm->phase2_target);
            return;
        }

        arm->settle_time_ms++;

        float pos_err = fabsf(arm->traj.q_end - arm->pos_deg);
        float vel_mag = fabsf(arm->vel_deg_s);

        /* หยุดขับเมื่อใกล้พอ */
        if (pos_err <= ARM_DONE_TOL_DEG) {
            _Motor_SetPWM(0.0f);
            arm->u_volt = 0.0f;
        }

        /* Done: error เล็กพอ หรือ หมดเวลา settle */
        bool settled  = (pos_err <= ARM_DONE_TOL_DEG && vel_mag <= ARM_DONE_TOL_VEL);
        bool timeout  = (arm->settle_time_ms >= ARM_SETTLE_TIMEOUT_MS);

        if (settled || timeout) {
            _Motor_SetPWM(0.0f);
            arm->u_volt         = 0.0f;
            arm->running        = false;
            arm->done           = true;
            arm->last_move_time = arm->move_time_ms;
        }
    } else {
        arm->settle_time_ms = 0;
    }
}
