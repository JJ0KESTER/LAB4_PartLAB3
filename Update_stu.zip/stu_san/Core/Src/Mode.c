/* ════════════════════════════════════════════════════════════════════════════
 * Mode.c — Robot mode handler implementations
 * ════════════════════════════════════════════════════════════════════════════
 */

#include "Mode.h"
#include "main.h"
#include "robot_arm.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <math.h>

/* ── Static pointer to reg[] (set by Mode_Init) ──────────────────────────── */
static u16u8_t *R = NULL;

/* ── Shared robot state ──────────────────────────────────────────────────── */
volatile float real_position_deg = 0.0f;
volatile float real_velocity = 0.0f;
volatile float real_accel = 0.0f;
volatile float sim_position_deg = 0.0f;
volatile uint8_t sim_enable = 0;
volatile RobotMode_t current_mode = ROBOT_IDLE;
SCurveTraj_t g_traj;

volatile uint16_t dbg_R_mode = 0;
volatile uint16_t dbg_raw_reg1 = 0;

/* ── Internal state ──────────────────────────────────────────────────────── */
static RobotMode_t last_mode = ROBOT_IDLE;
static float home_offset_deg = 0.0f;
static uint8_t jog_moving = 0;
static uint8_t p2p_moving = 0;
static uint8_t home_moving = 0;
static TestPhase_t test_phase = TEST_IDLE;
static uint16_t test_rep_cur = 0;
static uint8_t test_going = 0;

static uint8_t auto_state = 0;
static uint16_t current_pair = 0;
static uint16_t total_pairs = 0;

extern RobotArm_t g_arm;

volatile int check = 0;
volatile float target_degree = 0;
volatile float target_direc = 0;

volatile float step = 0.0f;
//volatile float another_step = 0.0f;
/* ── Helpers ─────────────────────────────────────────────────────────────── */
static float Reg_ToFloat(uint16_t raw) {
//	return (float) (int16_t) raw / 10.0f;
	return (float) ((int16_t) raw);
//	return (float)raw;
}
static uint16_t Float_ToReg(float val) {
	return (uint16_t) (int16_t) (val * 10.0f);
//	return (uint16_t) (int16_t) (val);
}

static void Robot_StartTrajTo(float target_deg) {
    float current_deg = g_arm.pos_deg;
    float diff = target_deg - current_deg;
    float degrees_to_move = fabsf(diff);
    float direction = (diff >= 0.0f) ? 1.0f : -1.0f;

    if (degrees_to_move > 0.0f) {
        RobotArm_Move(&g_arm, degrees_to_move, direction);
    }

    // หมายเหตุ: เอา g_traj.active = true; ออกได้เลย
    // เพราะตอนนี้หุ่นยนต์จริงจะใช้ S-Curve ที่อยู่ข้างใน g_arm.traj แทนครับ
}

/* ── Mode handlers ───────────────────────────────────────────────────────── */
//static void Mode_GoHome(void) {
//	if (!g_traj.active) {
//		Robot_StartTrajTo(home_offset_deg);
//		R[REG_TASK].U16 = 0x0001;
//	}
//	if (SCurve_IsDone(&g_traj)) {
//		R[REG_TASK].U16 = 0x0000;
//		R[REG_MODE].U16 = 0x0000;
//		current_mode = ROBOT_IDLE;
//	}
//}

static void Mode_GoHome(void) {
	/* หมุนไปที่ home_offset_deg แล้ว reset ตำแหน่งนั้นเป็น 0
	   ตัวอย่าง: pos=75°, home_offset=90° → หมุนอีก 15° → ถึงแล้ว reset=0 */

	if (!home_moving) {
		float diff = home_offset_deg - g_arm.pos_deg;
		if (fabsf(diff) < 1.0f) {
			/* อยู่ที่ home แล้ว — reset ทันที */
			RobotArm_Stop(&g_arm);
			RobotArm_ResetPosition(&g_arm);
			R[REG_TASK].U16 = 0x0000;
			R[REG_MODE].U16 = 0x0000;
			current_mode = ROBOT_IDLE;
			return;
		}
		Robot_StartTrajTo(home_offset_deg);  /* หมุนไปที่ตำแหน่ง home */
		R[REG_TASK].U16 = 0x0001;
		home_moving = 1;
		return;
	}

	if (home_moving && RobotArm_IsDone(&g_arm)) {
		/* ถึง home_offset_deg แล้ว → reset ตำแหน่งนั้นเป็น 0 */
		RobotArm_ResetPosition(&g_arm);
		R[REG_TASK].U16 = 0x0000;
		R[REG_MODE].U16 = 0x0000;
		home_moving = 0;
		current_mode = ROBOT_IDLE;
	}
}

volatile uint16_t dbg_jog_raw    = 0;
volatile uint16_t dbg_jog_sticky = 0; /* ค้างค่าสุดท้ายที่ไม่ใช่ 0 */

static void Mode_Jog(void) {
	R[REG_TASK].U16 = 0x0000;
	dbg_jog_raw = R[REG_JOG].U16;  /* debug เท่านั้น */

	/* reg[5] ถูก clear แล้วใน main.c — ใช้ latch เป็น single source of truth */
	if (modbus_jog_latch == 0) {
		/* ไม่มีคำสั่งใหม่ — แค่รอ arm เสร็จ */
		if (jog_moving && RobotArm_IsDone(&g_arm)) {
			jog_moving = 0;
		}
		return;
	}

	/* มีคำสั่ง jog — consume latch */
	step = (float)modbus_jog_latch;
	modbus_jog_latch = 0;

	float degrees_to_move = fabsf(step);
	float direction = (step >= 0.0f) ? 1.0f : -1.0f;

	dbg_jog_sticky = (uint16_t)degrees_to_move;

	if (degrees_to_move >= 0.5f) {   /* กรองค่าเล็กเกินไป */
		check = 1;
		target_degree = degrees_to_move;
		target_direc   = direction;
		RobotArm_Stop(&g_arm);
		RobotArm_Move(&g_arm, degrees_to_move, direction);
		jog_moving = 1;
	}
//	if (step != 0.0f && !jog_moving) {
//		check = 2;
//		RobotArm_Stop(&g_arm);
//        float degrees_to_move = fabsf(step);
////        target_degree = degrees_to_move;// เอาเฉพาะค่าบวก (Magnitude)
//        float direction = (step >= 0.0f) ? 1.0f : -1.0f; // กำหนดทิศ CW/CCW
////        float direction = 0.0f;
//        target_direc = direction;
//
//        if (degrees_to_move > 0.0f) {
//        	check = 1;
//            RobotArm_Move(&g_arm, degrees_to_move, direction);
//        }

//        if (step < 361.0f) {
////			degrees_to_move = fabsf(step) ;
//			direction = 1.0f;
//			target_direc = direction;
//			RobotArm_Move(&g_arm, step, direction);
////			direction = 0;
//		}
//        if (step > 360.0f) {
//
//			check = 999;
////			degrees_to_move = 65536.0f - fabsf(step);
//			direction = -1.0f;
//			target_direc = direction;
//			RobotArm_Move(&g_arm, 65536.0f - step, direction);
////			direction = 0;
//			target_direc = direction;
//		}

        // เคลียร์ค่าใน Register กลับเป็น 0 จะได้ไม่สั่งซ้ำ
//		R[REG_JOG].U16 = 0x0000;
//		jog_moving = 1;
//	}

    // รอจนกว่าแขนจะหยุด
	if (jog_moving && RobotArm_IsDone(&g_arm)) {
		jog_moving = 0;
    }
}

//static void Mode_Auto(void) {
//	if (!p2p_moving) {
//		float target;
//		if (R[REG_P2P_UNIT].U16 == 0x0000) {
//			target = Reg_ToFloat(R[REG_P2P_TARGET].U16);
//		} else {
//			int16_t idx = (int16_t) R[REG_P2P_TARGET].U16;
//			if (idx < 0 || idx >= 22)
//				return;
//			target = Reg_ToFloat(R[REG_PICKPLACE_START + idx].U16);
//		}
//		Robot_StartTrajTo(target);
//		R[REG_TASK].U16 = 0x0008;
//		p2p_moving = 1;
//	}
//	if (p2p_moving && SCurve_IsDone(&g_traj)) {
//		R[REG_TASK].U16 = 0x0000;
//		R[REG_MODE].U16 = 0x0000;
//		p2p_moving = 0;
//		current_mode = ROBOT_IDLE;
//	}
//}

//static void Mode_Auto(void) {
//    // เช็คว่าหน้าจอติ๊ก Gripper Enable มาหรือไม่
//    uint8_t use_gripper = (R[REG_GRIPPER_AUTO_EN].U16 & 0x0001);
//
//    switch (auto_state) {
//        case 0: // State 0: เริ่มต้นอ่านจำนวนคู่ (N_pare)
//            total_pairs = R[REG_PICKPLACE_COUNT].U16;
//            // เซฟตี้: ถ้าไม่มีคู่ให้หยิบ หรือเกิน 5 คู่ ให้ยกเลิก
//            if (total_pairs == 0 || total_pairs > 5) {
//                R[REG_TASK].U16 = 0x0000;
//                R[REG_MODE].U16 = 0x0000;
//                current_mode = ROBOT_IDLE;
//                return;
//            }
//            current_pair = 0;
//            auto_state = 1;
//            break;
//
//        case 1: // State 1: คำนวณและสั่งแขนกลไปจุด Pick
//        {
//            // ดึงค่า Index จุด Pick (ได้ค่าบวก/ลบ)
//            int16_t pick_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2)].U16;
//
//            // 1. แปลง Index เป็นองศาเป้าหมาย (จุดละ 5 องศา)
//            float target_deg = (float)pick_idx * 5.0f;
//
//            // 2. คำนวณระยะทางสัมพัทธ์และทิศทาง
//            float current_deg = g_arm.pos_deg;
//            float diff = target_deg - current_deg;
//
//            float degrees_to_move = fabsf(diff); // เอาแต่ค่าบวก (Magnitude)
//            float direction = (diff >= 0.0f) ? 1.0f : -1.0f; // กำหนดทิศ CW/CCW
//
//            // 3. สั่งแขนกลจริงขยับ (ถ้ามีระยะให้เดิน)
//            if (degrees_to_move > 0.0f) {
//                RobotArm_Move(&g_arm, degrees_to_move, direction);
//            }
//
////		if (sim_enable) {
////			extern TIM_HandleTypeDef htim2; // ดึงอินสแตนซ์ Encoder จาก main
////			// สั่งให้ตัวนับพัลส์วาร์ปไปที่ตำแหน่งเป้าหมายทันที (8192 พัลส์ = 360 องศา)
////			__HAL_TIM_SET_COUNTER(&htim2,
////					(int32_t )(target_deg * 8192.0f / 360.0f));
////		}
//            R[REG_TASK].U16 = 0x0002; // อัปเดต Task = Go Pick (ให้ UI โชว์)
//            auto_state = 2;
//            break;
//        }
//
//        case 2: // State 2: รอจนแขนกลถึงจุด Pick แล้วทำงาน
//            if (RobotArm_IsDone(&g_arm)) {
//                if (use_gripper) {
//                    Gripper_DoPick();
//                }
//                auto_state = 3; // ไปจุด Place ต่อ
//            }
//            break;
//
//        case 3: // State 3: คำนวณและสั่งแขนกลไปจุด Place
//        {
//            // ดึงค่า Index จุด Place
//            int16_t place_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2) + 1].U16;
//
//            float target_deg = (float)place_idx * 5.0f;
//
//            float current_deg = g_arm.pos_deg;
//            float diff = target_deg - current_deg;
//
//            float degrees_to_move = fabsf(diff);
//            float direction = (diff >= 0.0f) ? 1.0f : -1.0f;
//
//            if (degrees_to_move > 0.0f) {
//                RobotArm_Move(&g_arm, degrees_to_move, direction);
//            }
//
////		if (sim_enable) {
////			extern TIM_HandleTypeDef htim2;
////			__HAL_TIM_SET_COUNTER(&htim2,
////					(int32_t )(target_deg * 8192.0f / 360.0f));
////		}
//            R[REG_TASK].U16 = 0x0004; // อัปเดต Task = Go Place
//            auto_state = 4;
//            break;
//        }
//
//        case 4: // State 4: รอจนแขนกลถึงจุด Place จริงๆ
//            if (RobotArm_IsDone(&g_arm)) {
//                if (use_gripper) {
//                    Gripper_DoPlace();
//                }
//
//                current_pair++; // ขยับไปทำคู่ถัดไป
//
//                // เช็คว่าทำครบทุกคู่หรือยัง?
//                if (current_pair >= total_pairs) {
//                    R[REG_TASK].U16 = 0x0000;
//                    R[REG_MODE].U16 = 0x0000; // จบการทำงาน กลับไปโหมด Idle
//                    current_mode = ROBOT_IDLE;
//                    auto_state = 0;
//                } else {
//                    auto_state = 1; // วนกลับไป Pick ชิ้นถัดไป
//                }
//            }
//            break;
//    }
//}
static void Mode_Auto(void) {
    uint16_t count = R[REG_PICKPLACE_COUNT].U16;
    uint8_t  use_gripper = (R[REG_GRIPPER_AUTO_EN].U16 & 0x0001);

    switch (auto_state) {

        case 0: /* รอ GripperCheckbox Enable ส่งมา (เป็น trigger ว่าข้อมูลครบ) */
            Gripper_Open();
            /* REG_GRIPPER_AUTO_EN จะถูก write จาก base system เป็นอันสุดท้าย
               ถือว่าพร้อมเริ่มทำงานเมื่อ register นี้ถูก write แล้ว
               ใช้ count > 0 ประกอบด้วยเพื่อกันกรณีข้อมูลยังไม่มา */
            if (R[REG_GRIPPER_AUTO_EN].U16 != 0xFFFF && count > 0) {
                total_pairs = count;
                if (total_pairs > 10) {  /* safety clamp */
                    R[REG_TASK].U16  = 0x0000;
                    R[REG_MODE].U16  = 0x0000;
                    current_mode = ROBOT_IDLE;
                    return;
                }
                current_pair = 0;
                auto_state   = 1;
            }
            break;

        case 1: /* หมุนไปจุด Pick */
        {
            int16_t pick_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2)].U16;
            float   target_deg = (float)pick_idx * 5.0f;

            RobotArm_Stop(&g_arm);
            Robot_StartTrajTo(target_deg);
            R[REG_TASK].U16 = 0x0002;  /* Go Pick */
            auto_state = 2;
            break;
        }

        case 2: /* รอถึงจุด Pick */
            if (RobotArm_IsDone(&g_arm)) {
                if (use_gripper) {
                    Gripper_DoPick();  /* down -> close -> up */
                }
                auto_state = 3;
            }
            break;

        case 3: /* หมุนไปจุด Place */
        {
            int16_t place_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2) + 1].U16;
            float   target_deg = (float)place_idx * 5.0f;

            RobotArm_Stop(&g_arm);
            Robot_StartTrajTo(target_deg);
            R[REG_TASK].U16 = 0x0004;  /* Go Place */
            auto_state = 4;
            break;
        }

        case 4: /* รอถึงจุด Place */
            if (RobotArm_IsDone(&g_arm)) {
                if (use_gripper) {
                    Gripper_DoPlace();  /* down -> open -> up */
                }

                current_pair++;

                if (current_pair >= total_pairs) {
                    /* ทำครบทุก pair แล้ว */
                    Gripper_Open();  /* open ค้างไว้ */
                    R[REG_TASK].U16 = 0x0000;
                    R[REG_MODE].U16 = 0x0000;
                    auto_state   = 0;
                    current_mode = ROBOT_IDLE;
                } else {
                    auto_state = 1;  /* pair ถัดไป */
                }
            }
            break;
    }
}
//static void Mode_Auto(void) {
//    // 1. อ่านจำนวนคู่หยิบวาง (N_pare จาก Address 34) ออกมาตรวจสอบก่อน
//    uint16_t count = R[REG_PICKPLACE_COUNT].U16;
//
//    if (count == 0) {
//            /* ═════════════════════════════════════════════════════════════════════════
//             * [CASE A] โหมด Point-to-Point (P2P) — หมุนไปจุดเดี่ยวตามช่องพิกัดหน้าจอ
//             * ═════════════════════════════════════════════════════════════════════════ */
//            if (!p2p_moving) {
//                float target;
//                // ตรวจสอบหน่วย: 0 = เป็นองศาโดยตรง (scaled /10), 1 = เป็น Index ลำดับจุด
//                if (R[REG_P2P_UNIT].U16 == 0x0000) {
//                    target = Reg_ToFloat(R[REG_P2P_TARGET].U16); // ดึงค่าพิกัดจากช่อง Address 36
//                } else {
//                    int16_t idx = (int16_t) R[REG_P2P_TARGET].U16;
//                    if (idx < 0 || idx >= 22)
//                        return;
//                    target = Reg_ToFloat(R[REG_PICKPLACE_START + idx].U16);
//                }
//
//                Robot_StartTrajTo(target);
//
//                if (sim_enable) {
//    				// บังคับให้แกนประมวลผลวาร์ปพิกัดตามเป้าหมายของ P2P ทันที
//    				g_arm.pos_deg = target;
//    			}
//
//                R[REG_TASK].U16 = 0x0008; // อัปเดต Task = Go Point (0x0008) ตามคู่มือหน้าเว็บ
//                p2p_moving = 1;
//            }
//
//            /* ─── 🌟 ปรับปรุงการเช็กสถานะหยั่งรู้เพื่อให้ระบบจำลองอัปเดตทัน 🌟 ─── */
//            uint8_t move_done = 0;
//            if (sim_enable) {
//                // ถ้าเปิดโหมดจำลอง ถ้าค่าดีดไปเท่าเป้าหมายแล้ว ถือว่าเสร็จงาน
//            	float target_check = (R[REG_P2P_UNIT].U16 == 0x0000) ? Reg_ToFloat(R[REG_P2P_TARGET].U16) : Reg_ToFloat(R[REG_PICKPLACE_START + (int16_t)R[REG_P2P_TARGET].U16].U16);
//                if (fabsf(g_arm.pos_deg - target_check) < 0.1f) {
//                    move_done = 1;
//                }
//            } else {
//                // ถ้าต่อหุ่นยนต์จริง ให้ใช้ฟังก์ชันดักรอจนกว่ามอเตอร์จะจอดนิ่งสนิทจริงๆ
//                if (RobotArm_IsDone(&g_arm)) {
//                    move_done = 1;
//                }
//            }
//
//            // ดักรอจนกว่าเงื่อนไขความสำเร็จจะเป็นจริง
//            if (p2p_moving && move_done) {
//                R[REG_TASK].U16 = 0x0000; // เคลียร์สถานะงาน
//                R[REG_MODE].U16 = 0x0000; // เคลียร์ปุ่มโหมดบนหน้าจอเว็บกลับเป็นปกติ
//                p2p_moving = 0;           // รีเซ็ตสถานะ
//                current_mode = ROBOT_IDLE;// สแตนด์บายรอรับคำสั่งถัดไป
//            }
//        }
//    else {
//        /* ═════════════════════════════════════════════════════════════════════════
//         * [CASE B] โหมด Sequence (Pick & Place) — ไล่ทำตามตารางลำดับสถานีจนครบ
//         * ═════════════════════════════════════════════════════════════════════════ */
//        uint8_t use_gripper = (R[REG_GRIPPER_AUTO_EN].U16 & 0x0001);
//
//        switch (auto_state) {
//            case 0: // State 0: ตรวจสอบและบันทึกจำนวนรอบ
//                total_pairs = count;
//                if (total_pairs > 5) { // เซฟตี้ป้องกันข้อมูลตารางล้น
//                    R[REG_TASK].U16 = 0x0000;
//                    R[REG_MODE].U16 = 0x0000;
//                    current_mode = ROBOT_IDLE;
//                    return;
//                }
//                current_pair = 0;
//                auto_state = 1;
//                break;
//
//            case 1: // State 1: ค้นพิกัด Pick และสั่งแขนกลขยับ
//            {
//                int16_t pick_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2)].U16;
//                float target_deg = (float)pick_idx * 5.0f; // แปลงพิกัดจุดเป็นองศา (จุดละ 5 องศา)
//
//                Robot_StartTrajTo(target_deg);
//                R[REG_TASK].U16 = 0x0002; // Task = Go Pick (0x0002)
//                auto_state = 2;
//                break;
//            }
//
//            case 2: // State 2: รอแขนกลถึงจุด Pick แล้วคีบจับชิ้นงาน
//                if (RobotArm_IsDone(&g_arm)) {
//                    if (use_gripper) {
//                        Gripper_DoPick();
//                    }
//                    auto_state = 3;
//                }
//                break;
//
//            case 3: // State 3: ค้นพิกัด Place และสั่งแขนกลขยับ
//            {
//                int16_t place_idx = (int16_t)R[REG_PICKPLACE_START + (current_pair * 2) + 1].U16;
//                float target_deg = (float)place_idx * 5.0f;
//
//                Robot_StartTrajTo(target_deg);
//                R[REG_TASK].U16 = 0x0004; // Task = Go Place (0x0004)
//                auto_state = 4;
//                break;
//            }
//
//            case 4: // State 4: รอแขนกลถึงจุด Place แล้วปล่อยชิ้นงาน
//                if (RobotArm_IsDone(&g_arm)) {
//                    if (use_gripper) {
//                        Gripper_DoPlace();
//                    }
//
//                    current_pair++; // ขยับรอบถัดไป
//
//                    if (current_pair >= total_pairs) {
//                        R[REG_TASK].U16 = 0x0000;
//                        R[REG_MODE].U16 = 0x0000; // จบงานล้างปุ่มกดหน้าเว็บ
//                        current_mode = ROBOT_IDLE;
//                        auto_state = 0;
//                    } else {
//                        auto_state = 1; // วนลูปคู่หยิบวางสถานีถัดไป
//                    }
//                }
//                break;
//        }
//    }
//}

static void Mode_SetHome(void) {
	/* แค่บันทึกตำแหน่ง home ไว้ — ยังไม่ขยับ
	   REG_P2P_TARGET = ตำแหน่ง absolute (deg) ที่จะเป็น home ถัดไป */
	home_offset_deg = Reg_ToFloat(R[REG_P2P_TARGET].U16);
	R[REG_TASK].U16 = 0x0000;
	R[REG_MODE].U16 = 0x0000;
	current_mode = ROBOT_IDLE;
}

//static void Mode_Test(void) {
//	uint16_t test_type = R[REG_TEST_TYPE].U16 & 0x0001;
//	uint16_t repeat = R[REG_PREC_REPEAT].U16;
//	if (repeat == 0)
//		repeat = 1;
//
//	float pos_a, pos_b;
//	if (test_type == 0x0001) {
//		pos_a = home_offset_deg;
//		pos_b = home_offset_deg + 90.0f;
//	} else {
//		pos_a = Reg_ToFloat(R[REG_PREC_INIT].U16);
//		pos_b = Reg_ToFloat(R[REG_PREC_FINAL].U16);
//	}
//
//	switch (test_phase) {
//	case TEST_IDLE:
//		test_rep_cur = 0;
//		test_going = 0;
////		Robot_StartTrajTo(pos_a);
//		R[REG_TASK].U16 = 0x0008;
//		test_phase = TEST_RUNNING;
//		break;
//
//	case TEST_RUNNING:
//		if (!SCurve_IsDone(&g_traj))
//			break;
//		test_going = !test_going;
//		if (!test_going) {
//			test_rep_cur++;
//			if (test_rep_cur >= repeat) {
//				test_phase = TEST_DONE;
//				R[REG_TASK].U16 = 0x0000;
//				R[REG_MODE].U16 = 0x0000;
//				current_mode = ROBOT_IDLE;
//				break;
//			}
//		}
////		Robot_StartTrajTo(test_going ? pos_b : pos_a);
//		break;
//
//	case TEST_DONE:
//	default:
//		break;
//	}
//}
static void Mode_Test(void) {
	uint16_t test_type = R[REG_TEST_TYPE].U16 & 0x0001;
	uint16_t repeat = R[REG_PREC_REPEAT].U16;
	if (repeat == 0)
		repeat = 1;

	float pos_a, pos_b;
	if (test_type == 0x0001) {
		pos_a = home_offset_deg;
		pos_b = home_offset_deg + 90.0f;
	} else {
		pos_a = Reg_ToFloat(R[REG_PREC_INIT].U16);
		pos_b = Reg_ToFloat(R[REG_PREC_FINAL].U16);
	}

	switch (test_phase) {
	case TEST_IDLE:
		/* รอ parameter valid ก่อนเริ่ม */
		if (test_type == 0x0001) {
			float v_max = Reg_ToFloat(R[REG_PERF_VEL].U16);
			if (v_max <= 0.0f) break;
		} else {
			if (fabsf(pos_b - pos_a) < 0.1f) break;
		}
		test_rep_cur = 0;
		test_going = 0;
		Robot_StartTrajTo(pos_a);
		R[REG_TASK].U16 = 0x0008;
		test_phase = TEST_RUNNING;
		break;

	case TEST_RUNNING:

		if (!RobotArm_IsDone(&g_arm))
			break;

		test_going = !test_going;
		if (!test_going) {
			test_rep_cur++;
			if (test_rep_cur >= repeat) {
				test_phase = TEST_DONE;
				R[REG_TASK].U16 = 0x0000;
				R[REG_MODE].U16 = 0x0000;
				current_mode = ROBOT_IDLE;
				break;
			}
		}

		Robot_StartTrajTo(test_going ? pos_b : pos_a);
		break;

	case TEST_DONE:
	default:
		break;
	}
}

/* ── Public API ──────────────────────────────────────────────────────────── */
void Mode_Init(u16u8_t *reg_ptr) {
	R = reg_ptr; /* เก็บ pointer จาก main.c ไว้ใช้ทั้ง module */
	SCurve_Init(&g_traj);
}

void Mode_TrajTick(void) {
	if (!g_traj.active)
		return;
	TrajOutput_t ref = SCurve_Update(&g_traj);
	if (sim_enable) {
		real_position_deg = ref.position_deg;
		real_velocity = ref.velocity_deg_s;
		real_accel = ref.accel_deg_s2;
	}
}

void Mode_Update(void) {
	dbg_R_mode = R[REG_MODE].U16;
	dbg_raw_reg1 = R[1].U16;
	uint16_t mode_bits = R[REG_MODE].U16;

	if (mode_bits & MODE_HOME)
		current_mode = ROBOT_GOHOME;
	else if (mode_bits & MODE_JOG){
		current_mode = ROBOT_JOG;
		check = 3;}
	else if (mode_bits & MODE_AUTO){
		current_mode = ROBOT_AUTO;
		check = 33;}
	else if (mode_bits & MODE_SET_HOME)
		current_mode = ROBOT_SET_HOME;
	else if (mode_bits & MODE_TEST)
		current_mode = ROBOT_TEST;

	if (current_mode != last_mode) {

//		printf("[ROBOT MODE] Changed from Mode ID: %d ===> Mode ID: %d\r\n", last_mode, current_mode);

		RobotArm_Stop(&g_arm);

		g_traj.active = false;
		jog_moving = 0;
		p2p_moving = 0;
		test_phase = TEST_IDLE;
		auto_state = 0;
		home_moving = 0;
		test_rep_cur = 0;

		R[REG_GRIPPER_AUTO_EN].U16 = 0xFFFF;

		/* ไม่ล้าง REG_JOG — base system อาจส่ง step ก่อน mode */
		R[REG_TASK].U16 = 0x0000;

		last_mode = current_mode;
	}

	switch (current_mode) {
	case ROBOT_GOHOME:
		Mode_GoHome();
		break;
	case ROBOT_JOG:
		Mode_Jog();
		check = 4;
		break;
	case ROBOT_AUTO:
		Mode_Auto();
		check = 44;
		break;
	case ROBOT_SET_HOME:
		Mode_SetHome();
		break;
	case ROBOT_TEST:
		Mode_Test();
		break;
	default:
		R[REG_TASK].U16 = 0x0000;
		break;
	}
}

void Mode_UpdateFeedback(void) {
//	if (sim_enable) {
//			sim_position_deg  = g_arm.pos_deg;
			real_position_deg = g_arm.pos_deg;
			real_velocity     = g_arm.vel_deg_s;
//		}
	R[REG_POSITION].U16 = Float_ToReg(real_position_deg);
	R[REG_VELOCITY].U16 = Float_ToReg(real_velocity);
	R[REG_ACCELERATION].U16 = Float_ToReg(real_accel);
}
