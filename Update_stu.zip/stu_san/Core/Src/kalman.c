/**
 * @file    kalman.c
 * @brief   4-State Discrete Kalman Filter Implementation with Exact Discretization.
 */

#include "kalman.h"
#include <string.h>

#define M_PI_F 3.14159265358979323846f

/* ─── SYSTEM MATRICES (EXACT DISCRETIZATION AT Ts = 0.001s) ──────────────── */

static const float Ad[4][4] = {
    { 1.00000000e+00f,  9.97990017e-04f,  9.09506598e-07f, -4.70303654e-06f },
    { 0.00000000e+00f,  9.95258752e-01f,  1.43827060e-03f, -9.39844648e-03f },
    { 0.00000000e+00f, -1.53892100e+00f,  1.90616099e-01f,  9.16455646e-03f },
    { 0.00000000e+00f,  0.00000000e+00f,  0.00000000e+00f,  1.00000000e+00f }
};

static const float Bd[4] = {
    3.10993843e-07f,
    8.31881783e-04f,
    4.47415780e-01f,
    0.00000000e+00f
};

static const float Qd[4][4] = {
    {  1.000034e-06f,  5.090554e-08f, -6.167558e-08f, -1.568259e-07f },
    {  5.090554e-08f,  6.000000e-04f, -9.906813e-05f, -4.703037e-04f },
    { -6.167558e-08f, -9.906813e-05f,  4.071285e-04f,  3.426113e-04f },
    { -1.568259e-07f, -4.703037e-04f,  3.426113e-04f,  1.000000e-02f }
};

static const float R_sensor = 2.0e-3f;

/* ─── INITIALIZATION ────────────────────────────────────────────────────── */
void KalmanFilter_Init(KalmanFilter_t *kf)
{
    memset(kf->x, 0, sizeof(kf->x));
    memset(kf->P, 0, sizeof(kf->P));
    kf->P[0][0] = 0.1f;
    kf->P[1][1] = 0.1f;
    kf->P[2][2] = 0.1f;
    kf->P[3][3] = 1.0f;
}

/* ─── PREDICT STEP ──────────────────────────────────────────────────────── */
void KalmanFilter_Predict(KalmanFilter_t *kf, float u_volt)
{
    float x_next[4];
    float P_temp[4][4];

    for (int i = 0; i < 4; i++) {
        x_next[i] = (Ad[i][0] * kf->x[0]) +
                    (Ad[i][1] * kf->x[1]) +
                    (Ad[i][2] * kf->x[2]) +
                    (Ad[i][3] * kf->x[3]) +
                    (Bd[i] * u_volt);
    }
    memcpy(kf->x, x_next, sizeof(kf->x));

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            P_temp[i][j] = (Ad[i][0] * kf->P[0][j]) +
                           (Ad[i][1] * kf->P[1][j]) +
                           (Ad[i][2] * kf->P[2][j]) +
                           (Ad[i][3] * kf->P[3][j]);
        }
    }

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            kf->P[i][j] = (P_temp[i][0] * Ad[j][0]) +
                          (P_temp[i][1] * Ad[j][1]) +
                          (P_temp[i][2] * Ad[j][2]) +
                          (P_temp[i][3] * Ad[j][3]) +
                          Qd[i][j];
        }
    }
}

/* ─── UPDATE STEP ───────────────────────────────────────────────────────── */
void KalmanFilter_Update(KalmanFilter_t *kf, float y_meas_deg)
{
    float y_meas_rad = y_meas_deg * (M_PI_F / 180.0f);
    float residual   = y_meas_rad - kf->x[0];
    float S          = kf->P[0][0] + R_sensor;
    if (S < 1e-12f) return;
    float S_inv = 1.0f / S;

    float K[4];
    K[0] = kf->P[0][0] * S_inv;
    K[1] = kf->P[1][0] * S_inv;
    K[2] = kf->P[2][0] * S_inv;
    K[3] = kf->P[3][0] * S_inv;

    kf->x[0] += K[0] * residual;
    kf->x[1] += K[1] * residual;
    kf->x[2] += K[2] * residual;
    kf->x[3] += K[3] * residual;

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            kf->P[i][j] -= K[i] * kf->P[0][j];
        }
    }
}

/* ─── GETTERS ───────────────────────────────────────────────────────────── */
float Kalman_GetPositionDeg(const KalmanFilter_t *kf) {
    return kf->x[0] * (180.0f / M_PI_F);
}
float Kalman_GetVelocityDegS(const KalmanFilter_t *kf) {
    return kf->x[1] * (180.0f / M_PI_F);
}
float Kalman_GetCurrentAmp(const KalmanFilter_t *kf) {
    return kf->x[2];
}
float Kalman_GetDisturbanceNm(const KalmanFilter_t *kf) {
    return kf->x[3];
}
