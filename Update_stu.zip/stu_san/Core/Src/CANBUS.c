/**
 * @file    CANBUS.c
 * @brief   CAN Bus Driver — Protocol Spec v1.0.1
 *          STM32G474 Master | Gripper Node 0x10 | 500 kbps
 *
 * Hardware (CubeMX):
 *   FDCAN1 | Prescaler=34 | NomTimeSeg1=7 | NomTimeSeg2=2
 *
 * Flow:
 *   CANBUS_Init()    → กำหนด filter + start FDCAN
 *   CANBUS_Process() → ส่ง Heartbeat ทุก 500ms + poll Opto ทุก 100ms
 *   CANBUS_RxCallback() → decode ข้อความที่รับ
 */

#include "CANBUS.h"
#include <string.h>

/* ─── Private ───────────────────────────────────────────────────────────── */
static FDCAN_HandleTypeDef *hCAN = NULL;

volatile uint8_t  can_relay_state    = 0x00u;
volatile uint8_t  can_opto_state     = 0x00u;
volatile uint8_t  can_node_state     = CAN_NODE_BOOTING;
volatile uint32_t can_last_node_tick = 0u;

static uint32_t hb_tick   = 0u;
static uint32_t opto_tick = 0u;

/* ─── Internal: Transmit ────────────────────────────────────────────────── */
static HAL_StatusTypeDef _TX(uint32_t id, const uint8_t *data, uint8_t dlc)
{
    if (!hCAN) return HAL_ERROR;

    FDCAN_TxHeaderTypeDef hdr = {0};
    hdr.Identifier          = id;
    hdr.IdType              = FDCAN_STANDARD_ID;
    hdr.TxFrameType         = FDCAN_DATA_FRAME;
    hdr.DataLength          = (uint32_t)dlc << 16; /* FDCAN_DLC_BYTES_n */
    hdr.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    hdr.BitRateSwitch       = FDCAN_BRS_OFF;
    hdr.FDFormat            = FDCAN_CLASSIC_CAN;
    hdr.TxEventFifoControl  = FDCAN_NO_TX_EVENTS;
    hdr.MessageMarker       = 0;

    uint8_t buf[8] = {0};
    if (data && dlc) memcpy(buf, data, dlc > 8 ? 8 : dlc);

    return HAL_FDCAN_AddMessageToTxFifoQ(hCAN, &hdr, buf);
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  CANBUS_Init
 * ═══════════════════════════════════════════════════════════════════════════ */
void CANBUS_Init(FDCAN_HandleTypeDef *hfdcan)
{
    hCAN = hfdcan;

    /* ── Filter: รับเฉพาะ ID ที่มี lower byte = NODE_ID (0x10)
           mask 0x0FF → (rxID & 0xFF) == 0x10
           ครอบคลุม: 0x010, 0x110, 0x310, 0x510, 0x710
    ── */
    FDCAN_FilterTypeDef f = {0};
    f.IdType       = FDCAN_STANDARD_ID;
    f.FilterIndex  = 0;
    f.FilterType   = FDCAN_FILTER_MASK;
    f.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
    f.FilterID1    = CAN_NODE_ID;   /* 0x010 ใช้เป็น base (lower 8 = 0x10) */
    f.FilterID2    = 0x0FFu;        /* mask: เทียบแค่ lower 8 bits          */
    HAL_FDCAN_ConfigFilter(hCAN, &f);

    /* ── Reject unmatched IDs ── */
    HAL_FDCAN_ConfigGlobalFilter(hCAN,
        FDCAN_REJECT, FDCAN_REJECT,
        FDCAN_FILTER_REMOTE, FDCAN_FILTER_REMOTE);

    /* ── Enable RX FIFO0 interrupt ── */
    HAL_FDCAN_ActivateNotification(hCAN,
        FDCAN_IT_RX_FIFO0_NEW_MESSAGE, 0);

    /* ── Start FDCAN ── */
    HAL_FDCAN_Start(hCAN);

    hb_tick   = HAL_GetTick();
    opto_tick = HAL_GetTick();
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  CANBUS_Process — เรียกทุกรอบ while(1)
 * ═══════════════════════════════════════════════════════════════════════════ */
void CANBUS_Process(void)
{
    uint32_t now = HAL_GetTick();

    /* ── Master Heartbeat ทุก 500ms ── */
    if (now - hb_tick >= CAN_HB_PERIOD_MS) {
        hb_tick = now;
        uint8_t hb = CAN_MASTER_OP;
        _TX(CAN_ID_MASTER_HB, &hb, 1);
    }

    /* ── Poll Opto state ทุก 100ms ── */
    if (now - opto_tick >= CAN_OPTO_PERIOD_MS) {
        opto_tick = now;
        CANBUS_RequestOptos();
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  Low-Level Commands
 * ═══════════════════════════════════════════════════════════════════════════ */

HAL_StatusTypeDef CANBUS_SendRelayCmd(uint8_t relay_mask)
{
    uint8_t payload[3] = {
        CAN_INSTR_WRITE_REQ,   /* 0x10 */
        CAN_BANK_RELAY,        /* 0x00 */
        relay_mask
    };
    can_relay_state = relay_mask;
    return _TX(CAN_ID_CMD_REQ, payload, 3);
}

HAL_StatusTypeDef CANBUS_RequestOptos(void)
{
    uint8_t payload[2] = {
        CAN_INSTR_READ_REQ,    /* 0x20 */
        CAN_BANK_OPTO          /* 0x10 */
    };
    return _TX(CAN_ID_CMD_REQ, payload, 2);
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  Gripper High-Level API
 * ═══════════════════════════════════════════════════════════════════════════ */

void CANBUS_Gripper_Up(void)
{
    /* ปิด DOWN ก่อน แล้วเปิด UP */
    CANBUS_SendRelayCmd((can_relay_state & ~CAN_RELAY_DOWN) | CAN_RELAY_UP);
}

void CANBUS_Gripper_Down(void)
{
    CANBUS_SendRelayCmd((can_relay_state & ~CAN_RELAY_UP) | CAN_RELAY_DOWN);
}

void CANBUS_Gripper_Open(void)
{
    CANBUS_SendRelayCmd((can_relay_state & ~CAN_RELAY_CLOSE) | CAN_RELAY_OPEN);
}

void CANBUS_Gripper_Close(void)
{
    CANBUS_SendRelayCmd((can_relay_state & ~CAN_RELAY_OPEN) | CAN_RELAY_CLOSE);
}

void CANBUS_Gripper_Off(void)
{
    CANBUS_SendRelayCmd(0x00u);
}

void CANBUS_Gripper_DoPick(void)
{
    CANBUS_Gripper_Down();
    HAL_Delay(800);
    CANBUS_Gripper_Close();
    HAL_Delay(800);
    CANBUS_Gripper_Up();
    HAL_Delay(500);
}

void CANBUS_Gripper_DoPlace(void)
{
    CANBUS_Gripper_Down();
    HAL_Delay(800);
    CANBUS_Gripper_Open();
    HAL_Delay(800);
    CANBUS_Gripper_Up();
    HAL_Delay(500);
}

/* ═══════════════════════════════════════════════════════════════════════════
 *  RX Callback — เรียกจาก HAL_FDCAN_RxFifo0Callback
 * ═══════════════════════════════════════════════════════════════════════════ */
void CANBUS_RxCallback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
    if (hfdcan->Instance != hCAN->Instance) return;
    if (!(RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE)) return;

    FDCAN_RxHeaderTypeDef rxHdr;
    uint8_t rxData[8];

    while (HAL_FDCAN_GetRxMessage(hCAN, FDCAN_RX_FIFO0, &rxHdr, rxData) == HAL_OK) {
        uint32_t id = rxHdr.Identifier;

        if (id == CAN_ID_NODE_HB) {
            /* ── Node Heartbeat (0x710) ── */
            can_node_state     = rxData[0];
            can_last_node_tick = HAL_GetTick();
        }
        else if (id == CAN_ID_CMD_RESP) {
            /* ── Command Response (0x310) ── */
            if (rxData[0] == CAN_INSTR_WRITE_ACK) {
                /* Write ACK: Byte2 = actual relay state */
                can_relay_state = rxData[2];
            }
            else if (rxData[0] == CAN_INSTR_READ_RESP) {
                /* Read Response: Byte2 = opto bitmask */
                can_opto_state = rxData[2];
            }
        }
        else if (id == CAN_ID_RT_DATA) {
            /* ── Real-Time Opto Broadcast (0x110) ── */
            can_opto_state = rxData[0];
        }
        else if (id == CAN_ID_EMCY) {
            /* ── Emergency (0x010) ── */
            /* TODO: handle error code rxData[0] */
            CANBUS_Gripper_Off();
        }
    }
}
