#include "proximity.h"
#include "scurve_trajectory.h"
#include "Modbus.h"
#include "robot_arm.h"
#include "main.h"
#include <stdio.h>

//static bool last_s1_state = false;
//static bool last_s2_state = false;
//extern struct RobotArm_t g_arm;
extern RobotArm_t g_arm;
volatile int check_tickProx = 1;
extern home_enable;
/* * ฟังก์ชันสำหรับ Initialize ขา GPIO (ใช้กรณีที่ไม่ได้ตั้งค่าผ่าน CubeMX)
 * ถ้าตั้งค่าจาก CubeMX แล้ว (Set PA8, PA9 เป็น Input Pull-Up) สามารถข้ามการเรียกฟังก์ชันนี้ได้
 */
//void Proximity_Init(void)
//{
//    GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//    __HAL_RCC_GPIOA_CLK_ENABLE();
//
//    GPIO_InitStruct.Pin = PROXIMITY1_PIN | PROXIMITY2_PIN;
//    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
//    GPIO_InitStruct.Pull = GPIO_PULLUP; // เปิดใช้งาน Pull-up ภายใน
//    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
//}

/* * อ่านค่าจาก Sensor 1 (PA8)
 * NPN NO + Pull-up: เจอเหล็ก = 0 (LOW), ไม่เจอ = 1 (HIGH)
 * return true ถ้า "เจอเหล็ก (ตรวจจับได้)"
 */
//bool Proximity_Read_Sensor1(void)
//{
//    bool current_state = (HAL_GPIO_ReadPin(PROXIMITY1_PORT, PROXIMITY1_PIN) == GPIO_PIN_RESET);

    // ตรวจจับจังหวะที่เซนเซอร์เปลี่ยนสถานะ
//    if (current_state != last_s1_state) {
//        if (current_state) {
//            printf("[SENSOR 1] (PA8) -> O  DETECTED! (LOW)\r\n");
//        }
//        last_s1_state = current_state;
//    }
//    return current_state;
//}

void Proximity_Read_Sensor(void)
{
	check_tickProx = 3;
	/* สั่ง PWM ตรงๆ 8% ทิศ +1 — ไม่ผ่าน PID ช้าสม่ำเสมอ หยุดได้ทัน */
	RobotArm_DriveRaw(&g_arm, HOMING_PWM_PCT, 1.0f);   /* ปรับที่ control_config.h */
//    if ((!RobotArm_IsDone(&g_arm)) && HAL_GPIO_ReadPin(PROXIMITY2_PORT, PROXIMITY2_PIN) == 0) {
//	if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 1) {
//		check_tickProx = 0;
//		__disable_irq();
//		RobotArm_Stop(&g_arm);
//		__enable_irq();
////    	g_arm.pos_deg = 0;
////    	g_arm.vel_deg_s = 0;
//    	check_tickProx = 1;
//    	home_enable = 0;
//
//    }
//    return current_state;
}
