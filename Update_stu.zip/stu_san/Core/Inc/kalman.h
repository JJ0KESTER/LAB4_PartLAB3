/**
 * @file    kalman.h
 * @brief   4-State Discrete Kalman Filter with Exact Qd Matrix for STM32CubeIDE
 * Designed for FRA233 Lab 4 | Control Frequency: 1 kHz (Ts = 0.001s)
 */

#ifndef KALMAN_H
#define KALMAN_H

#include <stdint.h>
#include <stdbool.h>

/* ─── KALMAN FILTER STRUCT ──────────────────────────────────────────────── */
typedef struct {
    float x[4];        /* State vector: [theta_rad, omega_rad_s, current_amp, torque_nm] */
    float P[4][4];     /* Error Covariance Matrix */
} KalmanFilter_t;

/* ─── PUBLIC API ────────────────────────────────────────────────────────── */
void  KalmanFilter_Init    (KalmanFilter_t *kf);
void  KalmanFilter_Predict (KalmanFilter_t *kf, float u_volt);
void  KalmanFilter_Update  (KalmanFilter_t *kf, float y_meas_deg);

float Kalman_GetPositionDeg    (const KalmanFilter_t *kf);
float Kalman_GetVelocityDegS   (const KalmanFilter_t *kf);
float Kalman_GetCurrentAmp     (const KalmanFilter_t *kf);
float Kalman_GetDisturbanceNm  (const KalmanFilter_t *kf);

#endif /* KALMAN_H */
