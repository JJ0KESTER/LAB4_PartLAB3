/**
 * @file    robot_arm.h
 * @brief   1-DOF Robot Arm Library
 *          STM32 NUCLEO-G474RE
 */

#ifndef ROBOT_ARM_H
#define ROBOT_ARM_H

#include <stdint.h>
#include <stdbool.h>
#include "scurve_trajectory.h"
#include "kalman.h"
#include "control_config.h"   /* ← ค่าทุกอย่างที่ต้องจูนอยู่ที่นั่น */

/* derived — ไม่ต้องแก้ตรงนี้ */
#define ARM_POS_OUT_LIMIT       SCURVE_V_MAX_DEG_S
#define ARM_VEL_OUT_LIMIT       ARM_PWM_MAX
#define ARM_APPROACH_DIR        1.0f
#define ARM_BACKLASH_DEG        6.0f

/* ═══════════════════════════════════════════════════════════════════════════
 *  STRUCTS
 * ═══════════════════════════════════════════════════════════════════════════ */
typedef struct {
    float integral;
    float prev_error;
} PIDState_t;

typedef struct {
    /* S-Curve trajectory */
    SCurveTraj_t    traj;

    /* Current kinematic state */
    float           pos_deg;
    float           vel_deg_s;
    int32_t         encoder_raw;
    int32_t         encoder_last;

    /* PID states */
    PIDState_t      pos_pid;
    PIDState_t      vel_pid;

    /* Trajectory reference */
    float           ref_pos_deg;
    float           ref_vel_deg_s;

    /* Status */
    bool            running;
    bool            done;

    uint32_t        move_time_ms;
    uint32_t        last_move_time;

    bool            needs_approach;
    float           phase2_target;

    /* Kalman Filter */
    KalmanFilter_t  kf;
    float           u_volt;

    float           intended_target;
    uint32_t        settle_time_ms;   /* นับเวลาหลัง SCurve จบ */

    /* Manual PWM mode (สำหรับ homing) */
    bool            manual_mode;      /* true = ข้าม PID ใช้ manual_pwm โดยตรง */
    float           manual_pwm;       /* ค่า PWM raw [-ARM_PWM_MAX, ARM_PWM_MAX]  */
} RobotArm_t;

#define ARM_SETTLE_TIMEOUT_MS   3000u   /* เพิ่มเวลา settle ให้ถึงเป้าได้ */
#define ARM_OUTER_LOOP_DIV      10u

/* ═══════════════════════════════════════════════════════════════════════════
 *  PUBLIC API
 * ═══════════════════════════════════════════════════════════════════════════ */
void RobotArm_Init        (RobotArm_t *arm);
void RobotArm_Move        (RobotArm_t *arm, float degrees, float direction);
void RobotArm_MoveEx      (RobotArm_t *arm, float degrees, float direction,
                            float v_max, float a_max);
bool RobotArm_IsDone      (const RobotArm_t *arm);
void RobotArm_Stop        (RobotArm_t *arm);
void RobotArm_ResetTarget (RobotArm_t *arm);
void RobotArm_ControlTick (RobotArm_t *arm);

/* ── Manual PWM (homing ช้าๆ ข้าม PID) ─────────────────────────────────────
 *  pwm_pct : 0.0–1.0 (fraction ของ ARM_PWM_MAX)
 *  direction: +1 = CW, -1 = CCW
 * ──────────────────────────────────────────────────────────────────────────── */
void RobotArm_DriveRaw      (RobotArm_t *arm, float pwm_pct, float direction);

/* Reset encoder + Kalman → ตำแหน่งปัจจุบันกลายเป็น 0 */
void RobotArm_ResetPosition (RobotArm_t *arm);

#endif /* ROBOT_ARM_H */
