/**
 * @file    CANBUS.h
 * @brief   CAN Bus Driver — Protocol Spec v1.0.1
 *          STM32G474 as Master | Node ID 0x10 | 500 kbps
 */

#ifndef CANBUS_H
#define CANBUS_H

#include "stm32g4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/* ═══════════════════════════════════════════════════════════════════════════
 *  ID Construction
 *  11-bit: [Func(3)][NodeID(8)]
 * ═══════════════════════════════════════════════════════════════════════════ */
#define MAKE_CAN_ID(fc, nid)  (((uint32_t)((fc) & 0x07u) << 8) | ((nid) & 0xFFu))

#define CAN_NODE_ID           0x10u   /* Gripper Node ID */

/* ── Function Codes ─────────────────────────────────────────────────────── */
#define CAN_FC_EMCY           0x0u
#define CAN_FC_RT_DATA        0x1u
#define CAN_FC_CMD_REQ        0x2u
#define CAN_FC_CMD_RESP       0x3u
#define CAN_FC_CFG_REQ        0x4u
#define CAN_FC_CFG_RESP       0x5u
#define CAN_FC_MASTER_HB      0x6u
#define CAN_FC_NODE_HB        0x7u

/* ── CAN IDs ────────────────────────────────────────────────────────────── */
#define CAN_ID_EMCY           MAKE_CAN_ID(CAN_FC_EMCY,      CAN_NODE_ID) /* 0x010 */
#define CAN_ID_RT_DATA        MAKE_CAN_ID(CAN_FC_RT_DATA,   CAN_NODE_ID) /* 0x110 */
#define CAN_ID_CMD_REQ        MAKE_CAN_ID(CAN_FC_CMD_REQ,   CAN_NODE_ID) /* 0x210 */
#define CAN_ID_CMD_RESP       MAKE_CAN_ID(CAN_FC_CMD_RESP,  CAN_NODE_ID) /* 0x310 */
#define CAN_ID_CFG_REQ        MAKE_CAN_ID(CAN_FC_CFG_REQ,   CAN_NODE_ID) /* 0x410 */
#define CAN_ID_CFG_RESP       MAKE_CAN_ID(CAN_FC_CFG_RESP,  CAN_NODE_ID) /* 0x510 */
#define CAN_ID_MASTER_HB      MAKE_CAN_ID(CAN_FC_MASTER_HB, 0x00u)       /* 0x600 */
#define CAN_ID_NODE_HB        MAKE_CAN_ID(CAN_FC_NODE_HB,   CAN_NODE_ID) /* 0x710 */

/* ── Instructions ───────────────────────────────────────────────────────── */
#define CAN_INSTR_WRITE_REQ   0x10u
#define CAN_INSTR_READ_REQ    0x20u
#define CAN_INSTR_WRITE_ACK   0x11u
#define CAN_INSTR_READ_RESP   0x21u
#define CAN_INSTR_CFG_WRITE   0x40u

/* ── I/O Banks ──────────────────────────────────────────────────────────── */
#define CAN_BANK_RELAY        0x00u
#define CAN_BANK_OPTO         0x10u

/* ── Relay Bit Masks (Relay Bank 0) ─────────────────────────────────────── */
#define CAN_RELAY_UP          (1u << 0)   /* Gripper Up Solenoid   */
#define CAN_RELAY_DOWN        (1u << 1)   /* Gripper Down Solenoid */
#define CAN_RELAY_CLOSE       (1u << 2)   /* Gripper Close Solenoid*/
#define CAN_RELAY_OPEN        (1u << 3)   /* Gripper Open Solenoid */

/* ── Master Heartbeat States ────────────────────────────────────────────── */
#define CAN_MASTER_OP         0x05u       /* Operational */
#define CAN_MASTER_STOP       0x00u       /* Stopped     */

/* ── Node States ────────────────────────────────────────────────────────── */
#define CAN_NODE_BOOTING      0x00u
#define CAN_NODE_OPERATIONAL  0x05u
#define CAN_NODE_FAILSAFE     0xFFu

/* ── Timing ─────────────────────────────────────────────────────────────── */
#define CAN_HB_PERIOD_MS      500u    /* Master heartbeat interval */
#define CAN_OPTO_PERIOD_MS    100u    /* Opto poll interval        */

/* ── Shared State ───────────────────────────────────────────────────────── */
extern volatile uint8_t  can_relay_state;    /* Relay state ที่ส่งล่าสุด */
extern volatile uint8_t  can_opto_state;     /* Opto state ที่รับล่าสุด  */
extern volatile uint8_t  can_node_state;     /* Node state               */
extern volatile uint32_t can_last_node_tick; /* Tick ที่รับ node HB ล่าสุด */

/* ═══════════════════════════════════════════════════════════════════════════
 *  PUBLIC API
 * ═══════════════════════════════════════════════════════════════════════════ */
void CANBUS_Init    (FDCAN_HandleTypeDef *hfdcan);
void CANBUS_Process (void);   /* เรียกทุกรอบ while(1) */

/* Gripper High-Level */
void CANBUS_Gripper_Up    (void);
void CANBUS_Gripper_Down  (void);
void CANBUS_Gripper_Open  (void);
void CANBUS_Gripper_Close (void);
void CANBUS_Gripper_Off   (void);   /* ปิดทุก relay */

void CANBUS_Gripper_DoPick  (void);  /* Down→Close→Up (blocking) */
void CANBUS_Gripper_DoPlace (void);  /* Down→Open→Up  (blocking) */

/* Low-Level */
HAL_StatusTypeDef CANBUS_SendRelayCmd (uint8_t relay_mask);
HAL_StatusTypeDef CANBUS_RequestOptos (void);

/* เรียกจาก HAL_FDCAN_RxFifo0Callback ใน stm32g4xx_it.c */
void CANBUS_RxCallback (FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs);

#endif /* CANBUS_H */
