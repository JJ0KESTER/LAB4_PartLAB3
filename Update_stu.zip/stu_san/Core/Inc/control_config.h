/**
 * @file    control_config.h
 * @brief   ═══ รวมค่าทุกอย่างที่ต้องจูนไว้ที่เดียว ═══
 *          แก้ไฟล์นี้ไฟล์เดียวเพื่อปรับ control parameter ทั้งหมด
 */

#ifndef CONTROL_CONFIG_H
#define CONTROL_CONFIG_H

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  1. S-CURVE — NORMAL ZONE  (ช่วงเคลื่อนที่หลัก)                        ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ↑ เพิ่ม V → เร็วขึ้น          ↓ ลด V → ช้าลง smooth ขึ้น
 *  ↑ เพิ่ม A → เร่งเร็วขึ้น      ↓ ลด A → เร่งนุ่มนวลขึ้น
 *  ↑ เพิ่ม J → S-curve สั้นลง   ↓ ลด J → S-curve smooth ขึ้น  (t1 = A/J)
 */
#define SCURVE_V_MAX_DEG_S       300.0f   /* deg/s   ความเร็วสูงสุด          */
#define SCURVE_A_MAX_DEG_S2     3500.0f   /* deg/s²  อัตราเร่งสูงสุด         */
#define SCURVE_J_MAX_DEG_S3     4000.0f   /* deg/s³  อัตราเปลี่ยน accel      */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  2. S-CURVE — FINE ZONE  (ใกล้เป้า ≤ FINE_THRESHOLD)                   ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ลดความเร็วเพื่อความแม่นยำ — ควรต่ำกว่า Normal Zone
 */
#define ARM_FINE_V_MAX_DEG_S      50.0f   /* deg/s   ช้าลงใกล้เป้า           */
#define ARM_FINE_A_MAX_DEG_S2    150.0f   /* deg/s²  เร่งนุ่มนวลใกล้เป้า     */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  3. FINE ZONE THRESHOLD                                                 ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ระยะห่างจากเป้าที่จะเปลี่ยนจาก Normal → Fine zone
 *  ↑ เพิ่ม → เข้า fine zone เร็ว (เริ่มช้าเร็วขึ้น)
 *  ↓ ลด   → อยู่ใน normal zone นานขึ้น
 */
#define ARM_FINE_THRESHOLD_DEG    10.0f   /* deg */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  4. POSITION PID — NORMAL ZONE  (outer loop)                            ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  output = velocity setpoint [deg/s]
 *  ↑ KP → ตอบสนองเร็ว แต่ถ้าสูงเกินไปจะ overshoot / oscillate
 *  KI → ชดเชย steady-state error (ระวัง windup — ใส่ถ้าจำเป็น)
 */
#define ARM_POS_KP                1.0f
#define ARM_POS_KI                0.0f    /* เปิดเมื่อต้องการลด steady-state error */
#define ARM_POS_KD                0.0f
#define ARM_POS_I_LIMIT          50.0f   /* clamp integral [deg·s] */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  5. VELOCITY PID — NORMAL ZONE  (inner loop)                            ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  output = PWM command
 *  ↑ KP → ติดตาม velocity ref ได้ดีขึ้น แต่ถ้าสูงเกินจะกระตุก
 */
#define ARM_VEL_KP                2.0f
#define ARM_VEL_KI                0.0f
#define ARM_VEL_KD                0.0f
#define ARM_VEL_I_LIMIT         200.0f

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  6. POSITION PID — FINE ZONE  (outer loop)                              ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ควรสูงกว่า Normal เพื่อดึง arm เข้าเป้าให้แม่น
 */
#define ARM_POS_KP_FINE           0.0f
#define ARM_POS_KI_FINE           0.0f
#define ARM_POS_KD_FINE           0.0f

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  7. VELOCITY PID — FINE ZONE  (inner loop)                              ║
 * ╚══════════════════════════════════════════════════════════════════════════╝ */
#define ARM_VEL_KP_FINE           0.5f
#define ARM_VEL_KI_FINE           0.0f
#define ARM_VEL_KD_FINE           0.0f

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  8. FEEDFORWARD                                                         ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ช่วยให้มอเตอร์เริ่มหมุนทันทีโดยไม่ต้องรอ error สะสม
 *  ↑ เพิ่ม → มอเตอร์ตอบสนองเร็ว  (ถ้าสูงเกินจะ overshoot)
 *  Fine zone สูงกว่าเพื่อชดเชย friction ที่ความเร็วต่ำ
 */
#define ARM_FF_SCALE_NORMAL       0.06f   /* FF coefficient ช่วง normal */
#define ARM_FF_SCALE_FINE         0.035f   /* FF coefficient ช่วง fine   */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  9. DONE / SETTLE CONDITION                                             ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  arm ถือว่า "ถึงเป้า" เมื่อ: pos_error ≤ TOL_DEG && vel ≤ TOL_VEL
 *  หรือ: settle time เกิน TIMEOUT (force stop)
 */
#define ARM_DONE_TOL_DEG          0.5f    /* deg   — ±tolerance ตำแหน่ง  */
#define ARM_DONE_TOL_VEL          2.0f    /* deg/s — velocity ที่ถือว่าหยุด */
#define ARM_SETTLE_TIMEOUT_MS    3000u    /* ms    — force stop หากเกินนี้ */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  10. MOTOR MODEL  (ใช้ใน Feedforward และ Kalman)                        ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ค่าเหล่านี้ขึ้นอยู่กับ motor จริง — ถ้า FF แรงเกินให้ลด KE หรือ B
 */
#define MOTOR_KE                  3.4437f  /* V·s/rad  back-EMF constant */
#define MOTOR_B                  (0.1997f) /* N·m·s/rad viscous friction */
#define MOTOR_J                   0.1062f  /* kg·m²    moment of inertia */
#define MOTOR_EFF                 0.3013f  /* -        efficiency        */
#define MOTOR_VSUPPLY            24.0f     /* V        supply voltage    */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  11. HARDWARE  (ไม่ควรแก้ถ้าไม่เปลี่ยน hardware)                       ║
 * ╚══════════════════════════════════════════════════════════════════════════╝ */
#define ARM_PULSES_PER_REV        8192     /* counts/rev (encoder X4)    */
#define ARM_PWM_MAX               8500.0f  /* TIM1 ARR value             */
#define ARM_TIM_PWM_PERIOD        8500
#define ARM_PWM_DEADBAND          20.0f    /* PWM counts ต่ำกว่านี้มอเตอร์ไม่หมุน */
#define ARM_MOTOR_DIR_INVERT      1        /* 1 = กลับทิศ DIR signal     */
#define ARM_OUTER_LOOP_DIV        10u      /* outer PID ทุก N tick (10=100Hz) */

/* ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  12. HOMING (Proximity sensor)                                          ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *  ↑ เพิ่ม HOMING_PWM_PCT → หมุนเร็วขึ้น แต่หยุดช้าลง
 *  ↓ ลด   HOMING_PWM_PCT → หมุนช้า smooth หยุดแม่น
 */
#define HOMING_PWM_PCT            0.04f   /* 0.0–1.0 (fraction of ARM_PWM_MAX) */

#endif /* CONTROL_CONFIG_H */
